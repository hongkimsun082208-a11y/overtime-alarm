plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "kr.sigan.overtime"
    compileSdk = 34

    defaultConfig {
        applicationId = "kr.sigan.overtime"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // 빌드할 때마다 서명 키가 바뀌면 폰에서 덮어 설치가 안 된다.
    // 저장소의 signing/overtime.keystore (Actions 가 처음 한 번 만들어 보관) 로 늘 같은 키를 쓴다.
    val fixedKey = rootProject.file("signing/overtime.keystore")
    signingConfigs {
        create("fixed") {
            storeFile = fixedKey
            storePassword = "overtime"
            keyAlias = "overtime"
            keyPassword = "overtime"
        }
    }

    buildTypes {
        debug {
            if (fixedKey.exists()) signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            // 개인 설치용이라 디버그 키로 서명한다
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
