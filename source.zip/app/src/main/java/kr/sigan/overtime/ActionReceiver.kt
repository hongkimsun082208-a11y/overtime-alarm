package kr.sigan.overtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** 알림의 버튼들을 처리한다. */
class ActionReceiver : BroadcastReceiver() {

    companion object {
        const val A_YES = "kr.sigan.overtime.YES"
        const val A_NO = "kr.sigan.overtime.NO"
        const val A_DONE = "kr.sigan.overtime.DONE"
        const val A_LEAVE = "kr.sigan.overtime.LEAVE"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val p = Prefs(context)

        when (intent.action) {

            A_YES -> Scheduler.startEvening(context, p)

            A_NO -> Notifications.cancelAsk(context)

            // 업무 시스템에서 확인을 눌렀다 → 진동 알림만 치운다. 다음 확인 시각은 고정이라 그대로.
            A_DONE -> {
                p.pendingCheck = false
                p.nagCount = 0
                Scheduler.cancelNag(context)
                Notifications.cancelNag(context)
                Notifications.showStatus(context, p)
            }

            A_LEAVE -> Scheduler.leave(context, p, Scheduler.Reason.MANUAL)
        }
    }
}
