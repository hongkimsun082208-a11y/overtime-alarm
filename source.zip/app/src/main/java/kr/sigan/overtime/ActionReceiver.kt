package kr.sigan.overtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** 알림의 버튼들을 처리한다. */
class ActionReceiver : BroadcastReceiver() {

    companion object {
        const val A_YES = "kr.sigan.overtime.YES"
        const val A_NO = "kr.sigan.overtime.NO"
        const val A_DONE = "kr.sigan.overtime.DONE"
        const val A_FINISH = "kr.sigan.overtime.FINISH"
        const val A_SNOOZE = "kr.sigan.overtime.SNOOZE"
        const val A_RESUME = "kr.sigan.overtime.RESUME"

        /** [30분 미루기] 로 미루는 시간 */
        const val SNOOZE_MIN = 30
    }

    override fun onReceive(context: Context, intent: Intent) {
        val p = Prefs(context)

        when (intent.action) {

            A_YES -> Scheduler.startDay(context, p)

            A_NO -> Notifications.cancelAsk(context)

            A_DONE -> {
                if (!p.isActive()) {
                    Notifications.cancelNag(context)
                    return
                }
                val now = Scheduler.floorMinute(System.currentTimeMillis())
                p.lastDone = now
                p.pendingCheck = false
                p.nagCount = 0
                // 누른 시각을 기준으로 다음 확인 시각을 다시 센다
                p.anchor = now
                Scheduler.cancelNag(context)
                Notifications.cancelNag(context)
                Scheduler.scheduleNextCheck(context, p)
                Notifications.showStatus(context, p)
            }

            A_SNOOZE -> {
                if (!p.isActive()) return
                p.pendingCheck = false
                p.nagCount = 0
                p.anchor = Scheduler.floorMinute(System.currentTimeMillis()) +
                    SNOOZE_MIN * 60_000L
                Scheduler.cancelNag(context)
                Notifications.cancelNag(context)
                Scheduler.scheduleNextCheck(context, p)
                Notifications.showStatus(context, p)
            }

            A_RESUME -> Scheduler.resumeDay(context, p)

            A_FINISH -> Scheduler.finishDay(context, p, Scheduler.Reason.MANUAL)
        }
    }
}
