package kr.sigan.overtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val p = Prefs(context)

        when (intent.action) {

            Scheduler.ACTION_ASK -> {
                // 다음 질문은 어떤 경우에도 미리 예약해 둔다
                Scheduler.scheduleAsk(context, p)
                if (!p.enabled) return
                if (!p.askOnHolidays && Holidays.isHolidayFor(p, Calendar.getInstance())) return
                if (p.isActive()) return
                Notifications.showAsk(context, p)
            }

            Scheduler.ACTION_CHECK -> {
                if (!p.isActive()) return
                p.pendingCheck = true
                p.nagCount = 1
                // 다음 시간대 확인도 미리 예약(확인을 안 눌러도 일정이 유지된다)
                Scheduler.scheduleNextCheck(context, p)
                Notifications.showNag(context, p, stage = 1)
                Scheduler.scheduleNag(context, p)
                Notifications.showStatus(context, p)
            }

            Scheduler.ACTION_NAG -> {
                if (!p.isActive() || !p.pendingCheck) {
                    Scheduler.cancelNag(context)
                    return
                }
                val n = p.nagCount + 1
                p.nagCount = n
                if (n <= Scheduler.MAX_NAG) {
                    Notifications.showNag(context, p, stage = n)
                    Scheduler.scheduleNag(context, p)
                } else {
                    // 두 번 알렸는데 반응이 없다 → 퇴근한 것으로 본다
                    Scheduler.finishDay(context, p, Scheduler.Reason.AWAY)
                }
            }

            Scheduler.ACTION_END -> Scheduler.finishDay(context, p, Scheduler.Reason.AUTO)
        }
    }
}
