package kr.sigan.overtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val p = Prefs(context)

        when (intent.action) {

            Scheduler.ACTION_ASK -> {
                // 다음 질문은 어떤 경우에도 미리 예약해 둔다
                Scheduler.scheduleAsk(context, p)
                if (!p.enabled) return
                if (Scheduler.holidayToday(p)) return
                if (p.isActive()) return
                Notifications.showAsk(context, p)
            }

            Scheduler.ACTION_CHECK -> {
                if (!p.isActive() || p.activeHoliday) return
                p.pendingCheck = true
                p.nagCount = 1
                // 다음 확인도 미리 예약(눌렀든 안 눌렀든 매시 30분 고정)
                Scheduler.scheduleNextCheck(context, p)
                Notifications.showNag(context, p, stage = 1)
                Scheduler.scheduleNag(context, p)
                Notifications.showStatus(context, p)
            }

            Scheduler.ACTION_NAG -> {
                if (!p.isActive() || !p.pendingCheck) {
                    Scheduler.cancelNag(context)
                    return
                }
                val n = p.nagCount + 1
                p.nagCount = n
                // 한 번만 더 울리고 끝. 자동 종료는 하지 않는다.
                if (n <= Scheduler.MAX_NAG) Notifications.showNag(context, p, stage = n)
            }

            Scheduler.ACTION_END -> Scheduler.leave(context, p, Scheduler.Reason.AUTO)
        }
    }
}
