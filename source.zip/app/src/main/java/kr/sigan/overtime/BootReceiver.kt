package kr.sigan.overtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** 폰을 다시 켜거나 앱을 새로 깔아도 알람이 유지되게 한다. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val p = Prefs(context)
        Notifications.ensureChannels(context)
        Scheduler.scheduleAsk(context, p)

        if (p.isActive()) {
            Scheduler.scheduleNextCheck(context, p)
            Notifications.showStatus(context, p)
            if (p.pendingCheck) {
                val stage = if (p.nagCount < 1) 1 else p.nagCount
                Notifications.showNag(context, p, stage)
                Scheduler.scheduleNag(context, p)
            }
        }
    }
}
