package kr.sigan.overtime

import java.util.Calendar

/**
 * 관공서 공휴일 표.
 * 근로자의 날(5월 1일)은 공무원 휴일이 아니라서 넣지 않았다.
 * 표에 없는 연도는 토·일만 휴일로 본다. 그 해 공휴일은 앱에서 하루 단위로 지정하면 된다.
 */
object Holidays {

    const val FIRST_YEAR = 2026
    const val LAST_YEAR = 2027

    private val DATES: Set<Int> = hashSetOf(
        // ----- 2026 -----
        20260101,                      // 신정
        20260216, 20260217, 20260218,  // 설날 연휴
        20260301, 20260302,            // 삼일절(일) + 대체공휴일
        20260505,                      // 어린이날
        20260524, 20260525,            // 부처님오신날(일) + 대체공휴일
        20260603,                      // 전국동시지방선거
        20260606,                      // 현충일
        20260717,                      // 제헌절
        20260815, 20260817,            // 광복절(토) + 대체공휴일
        20260924, 20260925, 20260926,  // 추석 연휴
        20261003, 20261005,            // 개천절(토) + 대체공휴일
        20261009,                      // 한글날
        20261225,                      // 성탄절

        // ----- 2027 -----
        20270101,
        20270206, 20270207, 20270208, 20270209,
        20270301,
        20270303,                      // 대통령선거
        20270505,
        20270513,                      // 부처님오신날
        20270606,
        20270717, 20270719,
        20270815, 20270816,
        20270914, 20270915, 20270916,  // 추석 연휴
        20271003, 20271004,
        20271009, 20271011,
        20271225, 20271227
    )

    /** 20261103 같은 숫자 하나로 날짜를 나타낸다. */
    fun key(c: Calendar): Int =
        c.get(Calendar.YEAR) * 10000 +
            (c.get(Calendar.MONTH) + 1) * 100 +
            c.get(Calendar.DAY_OF_MONTH)

    fun keyToday(): Int = key(Calendar.getInstance())

    fun isWeekend(c: Calendar): Boolean {
        val d = c.get(Calendar.DAY_OF_WEEK)
        return d == Calendar.SATURDAY || d == Calendar.SUNDAY
    }

    fun isPublicHoliday(c: Calendar): Boolean = DATES.contains(key(c))

    /** 공휴일 표가 이 연도를 담고 있는지 */
    fun covered(c: Calendar): Boolean = c.get(Calendar.YEAR) in FIRST_YEAR..LAST_YEAR

    /**
     * 그날을 휴일(주말·공휴일)로 볼지. 사용자가 직접 지정해 둔 날은 그 지정을 따른다.
     */
    fun isHolidayFor(p: Prefs, c: Calendar): Boolean {
        p.dayTypeOverride(key(c))?.let { return it }
        return isWeekend(c) || isPublicHoliday(c)
    }

    fun isHolidayToday(p: Prefs): Boolean = isHolidayFor(p, Calendar.getInstance())

    /** 화면에 보여 줄 그날의 성격 */
    fun label(p: Prefs, c: Calendar): String {
        val forced = p.dayTypeOverride(key(c))
        if (forced != null) return if (forced) "휴일 (직접 지정)" else "평일 (직접 지정)"
        if (isPublicHoliday(c)) return "공휴일"
        val d = c.get(Calendar.DAY_OF_WEEK)
        if (d == Calendar.SATURDAY) return "토요일"
        if (d == Calendar.SUNDAY) return "일요일"
        return "평일"
    }
}
