package kr.sigan.overtime

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var p: Prefs

    private lateinit var tvStatus: TextView
    private lateinit var tvMonth: TextView
    private lateinit var tvRule: TextView

    private lateinit var swEnabled: MaterialSwitch
    private lateinit var swAskHolidays: MaterialSwitch
    private lateinit var swTodayHoliday: MaterialSwitch

    private lateinit var btnAsk: MaterialButton
    private lateinit var btnFirst: MaterialButton
    private lateinit var btnInterval: MaterialButton
    private lateinit var btnEnd: MaterialButton
    private lateinit var btnSnooze: MaterialButton

    private lateinit var btnStartTime: MaterialButton
    private lateinit var btnDinner: MaterialButton
    private lateinit var btnWeekCap: MaterialButton
    private lateinit var btnHolCap: MaterialButton
    private lateinit var btnMonthCap: MaterialButton

    /** 스위치를 코드로 바꿀 때 리스너가 도는 것을 막는다 */
    private var binding = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        p = Prefs(this)
        Notifications.ensureChannels(this)

        tvStatus = findViewById(R.id.tvStatus)
        tvMonth = findViewById(R.id.tvMonth)
        tvRule = findViewById(R.id.tvRule)

        swEnabled = findViewById(R.id.swEnabled)
        swAskHolidays = findViewById(R.id.swAskHolidays)
        swTodayHoliday = findViewById(R.id.swTodayHoliday)

        btnAsk = findViewById(R.id.btnAsk)
        btnFirst = findViewById(R.id.btnFirst)
        btnInterval = findViewById(R.id.btnInterval)
        btnEnd = findViewById(R.id.btnEnd)
        btnSnooze = findViewById(R.id.btnSnooze)

        btnStartTime = findViewById(R.id.btnStartTime)
        btnDinner = findViewById(R.id.btnDinner)
        btnWeekCap = findViewById(R.id.btnWeekCap)
        btnHolCap = findViewById(R.id.btnHolCap)
        btnMonthCap = findViewById(R.id.btnMonthCap)

        // ----- 알림 -----

        swEnabled.setOnCheckedChangeListener { _, v ->
            if (binding) return@setOnCheckedChangeListener
            p.enabled = v
            Scheduler.scheduleAsk(this, p)
            refresh()
        }

        swAskHolidays.setOnCheckedChangeListener { _, v ->
            if (binding) return@setOnCheckedChangeListener
            p.askOnHolidays = v
            Scheduler.scheduleAsk(this, p)
            refresh()
        }

        swTodayHoliday.setOnCheckedChangeListener { _, v ->
            if (binding) return@setOnCheckedChangeListener
            val c = Calendar.getInstance()
            val auto = Holidays.isWeekend(c) || Holidays.isPublicHoliday(c)
            // 자동 판정과 같으면 지정을 지워서 자동으로 되돌린다
            p.setDayTypeOverride(Holidays.key(c), if (v == auto) null else v)
            if (p.isActive()) {
                p.activeHoliday = v
                Notifications.showStatus(this, p)
            }
            Scheduler.scheduleAsk(this, p)
            refresh()
        }

        btnAsk.setOnClickListener {
            pickTime(p.askHour, p.askMinute) { h, m ->
                p.askHour = h; p.askMinute = m
                Scheduler.scheduleAsk(this, p)
                refresh()
            }
        }

        btnFirst.setOnClickListener {
            pickTime(p.firstHour, p.firstMinute) { h, m ->
                p.firstHour = h; p.firstMinute = m
                if (p.isActive() && !p.activeHoliday) {
                    p.anchor = Scheduler.todayAt(h, m)
                    Scheduler.scheduleNextCheck(this, p)
                    Notifications.showStatus(this, p)
                }
                refresh()
            }
        }

        btnEnd.setOnClickListener {
            pickTime(p.endHour, p.endMinute) { h, m ->
                p.endHour = h; p.endMinute = m
                if (p.isActive()) {
                    p.activeUntil = Scheduler.endTimeToday(p)
                    Scheduler.scheduleNextCheck(this, p)
                    Notifications.showStatus(this, p)
                }
                refresh()
            }
        }

        btnInterval.setOnClickListener {
            pick("확인 간격", intArrayOf(30, 60, 90, 120), p.intervalMin, ::minLabel) {
                p.intervalMin = it
                if (p.isActive()) {
                    Scheduler.scheduleNextCheck(this, p)
                    Notifications.showStatus(this, p)
                }
                refresh()
            }
        }

        btnSnooze.setOnClickListener {
            pick("다시 알림 간격", intArrayOf(2, 3, 5, 10), p.snoozeMin, ::minLabel) {
                p.snoozeMin = it
                refresh()
            }
        }

        // ----- 시간 계산 -----

        btnStartTime.setOnClickListener {
            pickTime(p.startHour, p.startMinute) { h, m ->
                p.startHour = h; p.startMinute = m
                if (p.isActive() && !p.activeHoliday) {
                    p.dayStart = Scheduler.todayAt(h, m)
                    Notifications.showStatus(this, p)
                }
                refresh()
            }
        }

        btnDinner.setOnClickListener {
            pick("석식 공제", intArrayOf(0, 30, 60, 90), p.dinnerMin, ::minLabel) {
                p.dinnerMin = it
                if (p.isActive()) Notifications.showStatus(this, p)
                refresh()
            }
        }

        btnWeekCap.setOnClickListener {
            pick("평일 하루 한도", intArrayOf(120, 180, 240, 300, 360), p.weekdayCapMin, ::hourLabel) {
                p.weekdayCapMin = it
                if (p.isActive()) Notifications.showStatus(this, p)
                refresh()
            }
        }

        btnHolCap.setOnClickListener {
            pick("휴일 하루 한도", intArrayOf(240, 360, 480, 600), p.holidayCapMin, ::hourLabel) {
                p.holidayCapMin = it
                if (p.isActive()) Notifications.showStatus(this, p)
                refresh()
            }
        }

        btnMonthCap.setOnClickListener {
            pick(
                "월 한도",
                intArrayOf(20 * 60, 25 * 60, 30 * 60, 35 * 60, 40 * 60, 57 * 60),
                p.monthlyCapMin, ::hourLabel
            ) {
                p.monthlyCapMin = it
                if (p.isActive()) Notifications.showStatus(this, p)
                refresh()
            }
        }

        // ----- 버튼 -----

        findViewById<MaterialButton>(R.id.btnStartNow).setOnClickListener {
            Scheduler.startDay(this, p)
            refresh()
        }

        findViewById<MaterialButton>(R.id.btnFinish).setOnClickListener {
            if (p.activeUntil <= 0L) {
                toast("진행 중인 시간외가 없어요")
            } else {
                val earned = Scheduler.finishDay(this, p, Scheduler.Reason.MANUAL)
                toast("오늘 ${WorkLog.text(earned)} 기록했어요")
            }
            refresh()
        }

        findViewById<MaterialButton>(R.id.btnLog).setOnClickListener { showMonthLog() }

        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener {
            Notifications.showNag(this, p, stage = 1)
        }

        findViewById<MaterialButton>(R.id.btnBattery).setOnClickListener {
            openBatterySettings()
        }

        findViewById<MaterialButton>(R.id.btnNotifSettings).setOnClickListener {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivitySafely(i)
        }

        askNotificationPermission()
        Scheduler.scheduleAsk(this, p)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ----- 화면 갱신 -----

    private fun refresh() {
        val c = Calendar.getInstance()
        val holidayToday = Holidays.isHolidayFor(p, c)
        val t = Totals.of(this, p)

        binding = true
        swEnabled.isChecked = p.enabled
        swAskHolidays.isChecked = p.askOnHolidays
        swTodayHoliday.isChecked = holidayToday
        binding = false

        btnAsk.text = pad("질문 시각", hm(p.askHour, p.askMinute))
        btnFirst.text = pad("첫 확인 시각", hm(p.firstHour, p.firstMinute))
        btnInterval.text = pad("확인 간격", "${p.intervalMin}분마다")
        btnEnd.text = pad("자동 종료 시각", hm(p.endHour, p.endMinute))
        btnSnooze.text = pad("다시 알림 간격", "${p.snoozeMin}분")

        btnStartTime.text = pad("평일 기산 시각", hm(p.startHour, p.startMinute))
        btnDinner.text = pad("석식 공제", if (p.dinnerMin == 0) "없음" else "${p.dinnerMin}분")
        btnWeekCap.text = pad("평일 하루 한도", WorkLog.text(p.weekdayCapMin))
        btnHolCap.text = pad("휴일 하루 한도", WorkLog.text(p.holidayCapMin))
        btnMonthCap.text = pad("월 한도", WorkLog.text(p.monthlyCapMin))

        tvRule.text = buildString {
            append("평일 — ${hm(p.startHour, p.startMinute)}부터 세고")
            if (p.dinnerMin > 0) append(" 석식 ${p.dinnerMin}분을 빼요")
            append(" (하루 최대 ${WorkLog.text(p.weekdayCapMin)})\n")
            append("휴일 — 시작한 시각부터 세요 (하루 최대 ${WorkLog.text(p.holidayCapMin)})\n")
            append("오늘은 ${Holidays.label(p, c)}")
        }

        tvMonth.text = buildString {
            val mon = c.get(Calendar.MONTH) + 1
            append("📊 ${mon}월 누적 ${WorkLog.text(t.month)} / ${WorkLog.text(t.cap)}\n")
            when {
                t.full -> append("⚠ 월 한도를 채웠어요\n")
                t.nearlyFull -> append("⚠ 한도까지 ${WorkLog.text(t.left)} 남았어요\n")
                else -> append("남은 시간 ${WorkLog.text(t.left)}\n")
            }
            append("이번 주 ${WorkLog.text(t.week)} · 오늘 ${WorkLog.text(t.today)}")
        }

        tvStatus.text = buildString {
            if (p.isActive()) {
                append(if (p.activeHoliday) "✅ 휴일 근무 중\n" else "✅ 시간외 근무 중\n")
                append("${Scheduler.fmt(p.dayStart)}부터 · 지금까지 ${WorkLog.text(t.today)}\n")
                val next = Scheduler.nextCheckAfter(p, System.currentTimeMillis())
                if (next > 0) append("다음 확인 ${Scheduler.fmt(next)}\n")
                else append("오늘 확인은 모두 끝났어요\n")
                append("${Scheduler.fmt(p.activeUntil)}에 자동 종료")
            } else if (!p.enabled) {
                append("⏸ 알림을 꺼 둔 상태예요")
            } else {
                append("😴 지금은 대기 중\n")
                append("다음 질문 ${Scheduler.fmtLong(Scheduler.nextAskTime(p))}")
                if (!p.askOnHolidays && holidayToday) {
                    append("\n오늘은 ${Holidays.label(p, c)}이라 안 물어봐요. 할 거면 [지금 시작]")
                }
                if (!Holidays.covered(c)) {
                    append("\n※ 공휴일 표는 ${Holidays.LAST_YEAR}년까지예요. 공휴일이면 [오늘을 휴일로 계산]을 켜 주세요")
                }
            }
        }
    }

    // ----- 이번 달 기록 -----

    private fun showMonthLog() {
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH) + 1
        val log = WorkLog(this)
        val rows = log.month(year, month)

        if (rows.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("${month}월 기록")
                .setMessage("아직 기록이 없어요.")
                .setPositiveButton("닫기", null)
                .show()
            return
        }

        val keys = IntArray(rows.size) { rows[it].first }
        val labels = Array(rows.size) { i ->
            "${WorkLog.dayText(rows[i].first)}    ${WorkLog.text(rows[i].second)}"
        }
        val total = log.monthTotal(year, month)

        AlertDialog.Builder(this)
            .setTitle("${month}월 기록 — 합계 ${WorkLog.text(total)}")
            .setItems(labels) { _, which -> editDay(keys[which]) }
            .setNegativeButton("닫기", null)
            .show()
    }

    /** 하루치 기록을 직접 고친다 */
    private fun editDay(dateKey: Int) {
        val options = IntArray(17) { it * 30 }
        val log = WorkLog(this)
        pick(WorkLog.dayText(dateKey), options, log.get(dateKey), ::hourLabel) {
            log.put(dateKey, it)
            refresh()
        }
    }

    // ----- 거들기 -----

    private fun pad(label: String, value: String): String = "$label   —   $value"

    private fun minLabel(v: Int): String = if (v == 0) "없음" else "${v}분"

    private fun hourLabel(v: Int): String = WorkLog.text(v)

    private fun hm(h: Int, m: Int): String {
        val ampm = if (h < 12) "오전" else "오후"
        var hh = h % 12
        if (hh == 0) hh = 12
        return "$ampm $hh:%02d".format(m)
    }

    private fun pickTime(h: Int, m: Int, onSet: (Int, Int) -> Unit) {
        TimePickerDialog(this, { _, hh, mm -> onSet(hh, mm) }, h, m, false).show()
    }

    private fun pick(
        title: String,
        options: IntArray,
        current: Int,
        label: (Int) -> String,
        onSet: (Int) -> Unit
    ) {
        val labels = Array(options.size) { label(options[it]) }
        var checked = options.indexOfFirst { it == current }
        if (checked < 0) checked = 0
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels, checked) { d, which ->
                onSet(options[which])
                d.dismiss()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1
            )
        }
    }

    private fun openBatterySettings() {
        val direct = Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:$packageName")
        )
        if (!startActivitySafely(direct)) {
            startActivitySafely(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun startActivitySafely(i: Intent): Boolean {
        return try {
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}
