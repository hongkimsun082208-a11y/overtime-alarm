package kr.sigan.overtime

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    companion object {
        /** 알림에서 "퇴근 시각 고치기" 로 들어올 때 고칠 날짜 */
        const val EXTRA_EDIT_DAY = "editDay"

        private const val MINUTE = 60_000L
        private const val DAY = 24 * 60 * MINUTE
    }

    private lateinit var p: Prefs

    private lateinit var cardToday: MaterialCardView
    private lateinit var tvKind: TextView
    private lateinit var tvToday: TextView
    private lateinit var tvDetail: TextView
    private lateinit var tvArrive: TextView
    private lateinit var tvNextLabel: TextView
    private lateinit var tvNext: TextView
    private lateinit var tvMonthLabel: TextView
    private lateinit var tvMonth: TextView
    private lateinit var tvMonthLeft: TextView
    private lateinit var progMonth: LinearProgressIndicator
    private lateinit var tvHint: TextView
    private lateinit var tvRule: TextView

    private lateinit var btnArrive: MaterialButton
    private lateinit var btnStart: MaterialButton
    private lateinit var btnLeave: MaterialButton
    private lateinit var btnSettings: MaterialButton
    private lateinit var settingsBox: LinearLayout

    private lateinit var swEnabled: MaterialSwitch
    private lateinit var swTodayHoliday: MaterialSwitch

    private lateinit var btnAsk: MaterialButton
    private lateinit var btnFirst: MaterialButton
    private lateinit var btnInterval: MaterialButton
    private lateinit var btnSnooze: MaterialButton
    private lateinit var btnStartTime: MaterialButton
    private lateinit var btnDinner: MaterialButton
    private lateinit var btnEarly: MaterialButton
    private lateinit var btnMonthCap: MaterialButton

    /** 카드 기본 색(대기 중일 때) */
    private lateinit var idleCardColor: ColorStateList
    private lateinit var idleTextColor: ColorStateList

    /** 스위치를 코드로 바꿀 때 리스너가 도는 것을 막는다 */
    private var binding = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        p = Prefs(this)
        Notifications.ensureChannels(this)

        cardToday = findViewById(R.id.cardToday)
        tvKind = findViewById(R.id.tvKind)
        tvToday = findViewById(R.id.tvToday)
        tvDetail = findViewById(R.id.tvDetail)
        tvArrive = findViewById(R.id.tvArrive)
        tvNextLabel = findViewById(R.id.tvNextLabel)
        tvNext = findViewById(R.id.tvNext)
        tvMonthLabel = findViewById(R.id.tvMonthLabel)
        tvMonth = findViewById(R.id.tvMonth)
        tvMonthLeft = findViewById(R.id.tvMonthLeft)
        progMonth = findViewById(R.id.progMonth)
        tvHint = findViewById(R.id.tvHint)
        tvRule = findViewById(R.id.tvRule)

        btnArrive = findViewById(R.id.btnArrive)
        btnStart = findViewById(R.id.btnStart)
        btnLeave = findViewById(R.id.btnLeave)
        btnSettings = findViewById(R.id.btnSettings)
        settingsBox = findViewById(R.id.settingsBox)

        swEnabled = findViewById(R.id.swEnabled)
        swTodayHoliday = findViewById(R.id.swTodayHoliday)

        btnAsk = findViewById(R.id.btnAsk)
        btnFirst = findViewById(R.id.btnFirst)
        btnInterval = findViewById(R.id.btnInterval)
        btnSnooze = findViewById(R.id.btnSnooze)
        btnStartTime = findViewById(R.id.btnStartTime)
        btnDinner = findViewById(R.id.btnDinner)
        btnEarly = findViewById(R.id.btnEarly)
        btnMonthCap = findViewById(R.id.btnMonthCap)

        idleCardColor = cardToday.cardBackgroundColor
        idleTextColor = tvToday.textColors

        // ----- 큰 버튼 -----

        btnArrive.setOnClickListener {
            toast(Scheduler.arrive(this, p))
            refresh()
        }

        btnStart.setOnClickListener {
            toast(Scheduler.startEvening(this, p))
            refresh()
        }

        btnLeave.setOnClickListener {
            if (p.activeUntil <= 0L) {
                toast("근무 중이 아니에요")
            } else {
                val total = Scheduler.leave(this, p, Scheduler.Reason.MANUAL)
                toast("퇴근 · 오늘 ${WorkLog.text(total)}")
            }
            refresh()
        }

        btnSettings.setOnClickListener {
            val show = settingsBox.visibility != View.VISIBLE
            settingsBox.visibility = if (show) View.VISIBLE else View.GONE
            btnSettings.text = if (show) "설정 ▴" else "설정 ▾"
        }

        findViewById<MaterialButton>(R.id.btnLog).setOnClickListener {
            val c = Calendar.getInstance()
            showMonthLog(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1)
        }

        // ----- 설정 -----

        swEnabled.setOnCheckedChangeListener { _, v ->
            if (binding) return@setOnCheckedChangeListener
            p.enabled = v
            Scheduler.scheduleAsk(this, p)
            if (p.isActive()) Scheduler.scheduleNextCheck(this, p)
            refresh()
        }

        swTodayHoliday.setOnCheckedChangeListener { _, v ->
            if (binding) return@setOnCheckedChangeListener
            if (p.isActive()) {
                toast("퇴근한 뒤에 바꿔 주세요")
                refresh()
                return@setOnCheckedChangeListener
            }
            val c = Calendar.getInstance()
            val auto = Holidays.isWeekend(c) || Holidays.isPublicHoliday(c)
            // 자동 판정과 같으면 지정을 지워서 자동으로 되돌린다
            p.setDayTypeOverride(Holidays.key(c), if (v == auto) null else v)
            Scheduler.scheduleAsk(this, p)
            refresh()
        }

        btnAsk.setOnClickListener {
            pickTime(p.askHour, p.askMinute) { h, m ->
                p.askHour = h; p.askMinute = m
                Scheduler.scheduleAsk(this, p)
                refresh()
            }
        }

        btnFirst.setOnClickListener {
            pickTime(p.firstHour, p.firstMinute) { h, m ->
                p.firstHour = h; p.firstMinute = m
                afterRuleChange()
            }
        }

        btnInterval.setOnClickListener {
            pick("확인 간격", intArrayOf(30, 60, 90, 120), p.intervalMin, ::minLabel) {
                p.intervalMin = it
                afterRuleChange()
            }
        }

        btnSnooze.setOnClickListener {
            pick("안 누르면 한 번 더 진동", intArrayOf(2, 3, 5, 10), p.snoozeMin, ::minLabel) {
                p.snoozeMin = it
                refresh()
            }
        }

        btnStartTime.setOnClickListener {
            pickTime(p.startHour, p.startMinute) { h, m ->
                p.startHour = h; p.startMinute = m
                if (p.isActive() && !p.activeHoliday) {
                    p.dayStart = WorkLog.at(p.activeDateKey, h, m)
                }
                afterRuleChange()
            }
        }

        btnDinner.setOnClickListener {
            pick("공제 (8시 이후 출근한 날)", intArrayOf(0, 30, 60, 90), p.dinnerMin, ::minLabel) {
                p.dinnerMin = it
                afterRuleChange()
            }
        }

        btnEarly.setOnClickListener {
            pickTime(p.earlyHour, p.earlyMinute) { h, m ->
                p.earlyHour = h; p.earlyMinute = m
                refresh()
            }
        }

        btnMonthCap.setOnClickListener {
            pick(
                "월 한도",
                intArrayOf(20 * 60, 25 * 60, 30 * 60, 35 * 60, 40 * 60, 57 * 60),
                p.monthlyCapMin, ::hourLabel
            ) {
                p.monthlyCapMin = it
                afterRuleChange()
            }
        }

        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener {
            Notifications.showTest(this)
        }

        findViewById<MaterialButton>(R.id.btnBattery).setOnClickListener {
            openBatterySettings()
        }

        findViewById<MaterialButton>(R.id.btnNotifSettings).setOnClickListener {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivitySafely(i)
        }

        askNotificationPermission()
        Scheduler.scheduleAsk(this, p)
        handleEditIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleEditIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun handleEditIntent(i: Intent?) {
        val key = i?.getIntExtra(EXTRA_EDIT_DAY, 0) ?: 0
        if (key > 0) {
            i?.removeExtra(EXTRA_EDIT_DAY)
            editDay(key)
        }
    }

    /** 규칙을 바꾼 뒤: 진행 중이면 알람·알림을 다시 맞춘다 */
    private fun afterRuleChange() {
        if (p.isActive()) {
            Scheduler.scheduleNextCheck(this, p)
            Notifications.showStatus(this, p)
        }
        refresh()
    }

    // ----- 화면 갱신 -----

    private fun refresh() {
        Scheduler.catchUp(this, p)

        val c = Calendar.getInstance()
        val key = Holidays.key(c)
        val holiday = Holidays.isHolidayFor(p, c)
        val log = WorkLog(this)
        val t = Totals.of(this, p)
        val active = p.isActive()
        val early = log.isEarly(key)
        val arrival = log.arrival(key)
        val now = System.currentTimeMillis()

        // 오늘 카드
        tvToday.text = WorkLog.text(t.today)
        if (active) {
            cardToday.setCardBackgroundColor(Color.parseColor("#DCEFE0"))
            val dark = ColorStateList.valueOf(Color.parseColor("#1E4D2B"))
            tvKind.setTextColor(dark); tvToday.setTextColor(dark); tvDetail.setTextColor(dark)
        } else {
            cardToday.setCardBackgroundColor(idleCardColor)
            tvKind.setTextColor(idleTextColor); tvToday.setTextColor(idleTextColor)
            tvDetail.setTextColor(idleTextColor)
        }

        when {
            active && p.activeHoliday -> {
                tvKind.text = "휴일 근무 중"
                tvDetail.text = "${Scheduler.fmt(p.dayStart)} 출근 · 공제 없음"
            }
            active -> {
                tvKind.text = if (early) "시간외 근무 중 · 8시 전 출근한 날" else "시간외 근무 중"
                val from = Scheduler.eveningCountFrom(this, p, key)
                tvDetail.text = if (now < from) "${Scheduler.fmt(from)}부터 누적돼요"
                else "${Scheduler.fmt(from)}부터 누적" + (if (early) " · 아침 출근분 포함" else "")
            }
            holiday -> {
                tvKind.text = "오늘은 ${Holidays.label(p, c)}"
                tvDetail.text = if (t.today > 0) "오늘 기록 · ${log.detail(p, key)}"
                else "출근을 누르면 퇴근까지 누적해요 (알림 없음)"
            }
            else -> {
                tvKind.text = if (early) "대기 중 · 8시 전 출근한 날" else "대기 중"
                val d = log.detail(p, key)
                tvDetail.text = if (d.isNotEmpty()) d
                else "다음 질문 ${Scheduler.fmtLong(Scheduler.nextAskTime(p))}"
            }
        }

        // 출근 / 다음 확인
        tvArrive.text = if (arrival > 0L) Scheduler.fmt(arrival) else "—"
        when {
            holiday || (active && p.activeHoliday) -> {
                tvNextLabel.text = "알림"
                tvNext.text = "없음"
            }
            active -> {
                tvNextLabel.text = "다음 확인"
                val next = Scheduler.nextCheckAfter(p, now)
                tvNext.text = if (!p.enabled) "꺼짐" else if (next > 0) Scheduler.fmt(next) else "끝"
            }
            else -> {
                tvNextLabel.text = "질문"
                tvNext.text = if (p.enabled) Scheduler.fmt(Scheduler.todayAt(p.askHour, p.askMinute)) else "꺼짐"
            }
        }

        // 이번 달
        val mon = c.get(Calendar.MONTH) + 1
        tvMonthLabel.text = "${mon}월 누적"
        tvMonth.text = "${WorkLog.text(t.month)} / ${WorkLog.text(t.cap)}"
        val ratio = if (t.cap > 0) (t.month * 1000L / t.cap).toInt().coerceIn(0, 1000) else 0
        progMonth.setProgressCompat(ratio, false)
        tvMonthLeft.text = when {
            t.full -> "⚠ 월 한도를 채웠어요"
            t.nearlyFull -> "⚠ 한도까지 ${WorkLog.text(t.left)} 남았어요"
            else -> "남은 시간 ${WorkLog.text(t.left)} · 이번 주 ${WorkLog.text(t.week)}"
        }

        // 버튼
        btnStart.visibility = if (holiday) View.GONE else View.VISIBLE
        btnArrive.text = if (arrival > 0L && !holiday) "출근 ${Scheduler.fmt(arrival)}" else "출근"
        btnLeave.isEnabled = true
        btnLeave.alpha = if (active) 1f else 0.5f

        tvHint.text = when {
            active -> "퇴근할 때 [퇴근]을 눌러 주세요. 안 누르면 00시에 자동 종료돼요."
            holiday -> "주말·공휴일은 알림 없이 출근~퇴근만 누적해요."
            Scheduler.beforeEarly(p) && arrival == 0L ->
                "${hm(p.earlyHour, p.earlyMinute)} 전이에요. 출근을 누르면 그날 저녁은 18시부터 세요."
            else -> ""
        }

        // 설정
        binding = true
        swEnabled.isChecked = p.enabled
        swTodayHoliday.isChecked = holiday
        binding = false

        btnAsk.text = pad("질문 시각", hm(p.askHour, p.askMinute))
        btnFirst.text = pad("첫 확인 시각", hm(p.firstHour, p.firstMinute))
        btnInterval.text = pad("확인 간격", "${p.intervalMin}분마다")
        btnSnooze.text = pad("안 누르면 한 번 더", "${p.snoozeMin}분 뒤")
        btnStartTime.text = pad("저녁 기산 시각", hm(p.startHour, p.startMinute))
        btnDinner.text = pad("공제", if (p.dinnerMin == 0) "없음" else "${p.dinnerMin}분")
        btnEarly.text = pad("조기 출근 기준", hm(p.earlyHour, p.earlyMinute))
        btnMonthCap.text = pad("월 한도", WorkLog.text(p.monthlyCapMin))

        val s = hm(p.startHour, p.startMinute)
        val e = hm(p.earlyHour, p.earlyMinute)
        tvRule.text = buildString {
            append("• ${e} 이후 출근: 저녁 ${s}부터 세고 ${p.dinnerMin}분 공제\n")
            append("• ${e} 전 출근([출근] 누름): 출근~${e} 인정, 저녁은 ${s}부터 공제 없이\n")
            append("• 주말·공휴일: 출근~퇴근 그대로, 알림 없음\n")
            append("• 하루 한도 없음 · 퇴근 안 누르면 00시 자동 종료\n")
            append("• 오늘은 ${Holidays.label(p, c)}")
            if (!Holidays.covered(c)) append(" (공휴일 표는 ${Holidays.LAST_YEAR}년까지)")
        }
    }

    // ----- 이번 달 기록 -----

    private fun showMonthLog(year: Int, month: Int) {
        val log = WorkLog(this)
        val rows = log.month(year, month)
        val total = log.monthTotal(year, month)

        val b = AlertDialog.Builder(this)
            .setTitle("${month}월 기록 — 합계 ${WorkLog.text(total)}")
            .setNegativeButton("닫기", null)
            .setNeutralButton("날짜 골라 고치기") { _, _ -> pickDate(year, month) }

        if (rows.isEmpty()) {
            b.setMessage("아직 기록이 없어요.")
        } else {
            val keys = IntArray(rows.size) { rows[it].first }
            val labels = Array(rows.size) { i ->
                val d = log.detail(p, rows[i].first)
                "${WorkLog.dayText(rows[i].first)}   ${WorkLog.text(rows[i].second)}" +
                    (if (d.isNotEmpty()) "\n      $d" else "")
            }
            b.setItems(labels) { _, which -> editDay(keys[which]) }
        }
        b.show()
    }

    private fun pickDate(year: Int, month: Int) {
        val c = Calendar.getInstance()
        val day = if (c.get(Calendar.YEAR) == year && c.get(Calendar.MONTH) + 1 == month)
            c.get(Calendar.DAY_OF_MONTH) else 1
        DatePickerDialog(this, { _, y, m, d ->
            editDay(y * 10000 + (m + 1) * 100 + d)
        }, year, month - 1, day).show()
    }

    /** 하루치 기록 고치기 */
    private fun editDay(key: Int) {
        val log = WorkLog(this)
        val segs = log.segments(key)
        val holiday = Holidays.isHolidayFor(p, WorkLog.calOf(key))
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        for ((i, s) in segs.withIndex()) {
            when (s.kind) {
                'M' -> {
                    labels.add("출근 시각 ${Scheduler.fmt(s.start)} 고치기")
                    actions.add { editArrival(key, i) }
                }
                'E' -> {
                    labels.add("퇴근 시각 ${Scheduler.fmt(s.end)} 고치기")
                    actions.add { editEveningEnd(key, i) }
                }
                'H' -> {
                    labels.add("휴일 ${Scheduler.fmt(s.start)}~${Scheduler.fmt(s.end)} 고치기")
                    actions.add { editHoliday(key, i) }
                }
            }
        }
        if (!holiday && segs.none { it.kind == 'M' }) {
            labels.add("8시 전 출근 넣기")
            actions.add { editArrival(key, -1) }
        }
        if (!holiday && segs.none { it.kind == 'E' }) {
            labels.add("저녁 시간외 넣기 (퇴근 시각)")
            actions.add { editEveningEnd(key, -1) }
        }
        if (holiday) {
            labels.add("휴일 근무 넣기")
            actions.add { editHoliday(key, -1) }
        }
        labels.add("합계 직접 입력")
        actions.add {
            val options = IntArray(25) { it * 30 }
            pick(WorkLog.dayText(key), options, log.get(key), ::hourLabel) {
                log.put(key, it); refresh()
            }
        }
        labels.add("이 날 기록 지우기")
        actions.add {
            AlertDialog.Builder(this)
                .setMessage("${WorkLog.dayText(key)} 기록을 지울까요?")
                .setPositiveButton("지우기") { _, _ -> log.clear(key); refresh() }
                .setNegativeButton("취소", null)
                .show()
        }

        AlertDialog.Builder(this)
            .setTitle("${WorkLog.dayText(key)} · ${WorkLog.text(log.get(key))}")
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .setNegativeButton("닫기", null)
            .show()
    }

    /** idx < 0 이면 새로 넣기 */
    private fun replaceSeg(key: Int, idx: Int, seg: WorkLog.Seg?) {
        val log = WorkLog(this)
        val list = log.segments(key).toMutableList()
        if (idx >= 0 && idx < list.size) {
            if (seg == null) list.removeAt(idx) else list[idx] = seg
        } else if (seg != null) {
            list.add(seg)
        }
        val total = log.setSegments(p, key, list)
        toast("${WorkLog.dayText(key)} 합계 ${WorkLog.text(total)}")
        if (p.isActive()) Notifications.showStatus(this, p)
        refresh()
    }

    private fun editArrival(key: Int, idx: Int) {
        val early = WorkLog.at(key, p.earlyHour, p.earlyMinute)
        val cur = WorkLog(this).segments(key).getOrNull(idx)
        val c = Calendar.getInstance()
        c.timeInMillis = cur?.start ?: (early - 30 * MINUTE)
        pickTime(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)) { h, m ->
            val start = WorkLog.at(key, h, m)
            if (start >= early) {
                toast("${hm(p.earlyHour, p.earlyMinute)} 이후 출근이라 출근 기록을 뺐어요")
                replaceSeg(key, idx, null)
            } else {
                replaceSeg(key, idx, WorkLog.Seg('M', start, early))
            }
        }
    }

    private fun editEveningEnd(key: Int, idx: Int) {
        val start = WorkLog.at(key, p.startHour, p.startMinute)
        val cur = WorkLog(this).segments(key).getOrNull(idx)
        val c = Calendar.getInstance()
        c.timeInMillis = cur?.end ?: (start + 3 * 60 * MINUTE)
        pickTime(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)) { h, m ->
            var end = WorkLog.at(key, h, m)
            // 기산 시각보다 이른 시각을 고르면 밤 12시로 본다
            if (end <= start) end = WorkLog.at(key, 0, 0) + DAY
            replaceSeg(key, idx, WorkLog.Seg('E', cur?.start ?: start, end))
        }
    }

    private fun editHoliday(key: Int, idx: Int) {
        val cur = WorkLog(this).segments(key).getOrNull(idx)
        val c = Calendar.getInstance()
        c.timeInMillis = cur?.start ?: WorkLog.at(key, 9, 0)
        toast("출근 시각을 고르세요")
        pickTime(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)) { h1, m1 ->
            val start = WorkLog.at(key, h1, m1)
            c.timeInMillis = cur?.end ?: (start + 4 * 60 * MINUTE)
            toast("퇴근 시각을 고르세요")
            pickTime(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)) { h2, m2 ->
                var end = WorkLog.at(key, h2, m2)
                if (end <= start) end = WorkLog.at(key, 0, 0) + DAY
                replaceSeg(key, idx, WorkLog.Seg('H', start, end))
            }
        }
    }

    // ----- 거들기 -----

    private fun pad(label: String, value: String): String = "$label   —   $value"

    private fun minLabel(v: Int): String = if (v == 0) "없음" else "${v}분"

    private fun hourLabel(v: Int): String = WorkLog.text(v)

    private fun hm(h: Int, m: Int): String = "%02d:%02d".format(h, m)

    private fun pickTime(h: Int, m: Int, onSet: (Int, Int) -> Unit) {
        TimePickerDialog(this, { _, hh, mm -> onSet(hh, mm) }, h, m, true).show()
    }

    private fun pick(
        title: String,
        options: IntArray,
        current: Int,
        label: (Int) -> String,
        onSet: (Int) -> Unit
    ) {
        val labels = Array(options.size) { label(options[it]) }
        var checked = options.indexOfFirst { it == current }
        if (checked < 0) checked = 0
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels, checked) { d, which ->
                onSet(options[which])
                d.dismiss()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1
            )
        }
    }

    private fun openBatterySettings() {
        val direct = Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:$packageName")
        )
        if (!startActivitySafely(direct)) {
            startActivitySafely(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun startActivitySafely(i: Intent): Boolean {
        return try {
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}
