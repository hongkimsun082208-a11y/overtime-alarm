package kr.sigan.overtime

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat

/** 알림을 만들어 띄우는 곳. 소리는 쓰지 않고 진동만 쓴다. */
object Notifications {

    private const val CH_ASK = "ask_v3"
    private const val CH_ALARM = "alarm_vib_v3"
    private const val CH_STATUS = "status"

    private const val ID_ASK = 1
    private const val ID_NAG = 2
    private const val ID_STATUS = 3
    private const val ID_DONE = 4

    /** 1차 진동 — 짧게 세 번 */
    private val VIB1 = longArrayOf(0, 500, 300, 500, 300, 500)

    /** 2차 진동 — 길게 네 번 */
    private val VIB2 = longArrayOf(0, 900, 350, 900, 350, 900, 350, 900)

    private fun nm(ctx: Context) =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val m = nm(ctx)

        if (m.getNotificationChannel(CH_ASK) == null) {
            val ch = NotificationChannel(
                CH_ASK, "시간외 근무 여부 질문", NotificationManager.IMPORTANCE_HIGH
            )
            ch.description = "평일 저녁에 오늘 시간외 근무를 하는지 한 번 물어봅니다. 진동만 울립니다."
            ch.enableVibration(true)
            ch.vibrationPattern = VIB1
            ch.setSound(null, null)
            m.createNotificationChannel(ch)
        }

        if (m.getNotificationChannel(CH_ALARM) == null) {
            val ch = NotificationChannel(
                CH_ALARM, "확인 알람 (진동)", NotificationManager.IMPORTANCE_HIGH
            )
            ch.description = "시간외 확인을 누르라고 진동으로 알려 줍니다. 소리는 울리지 않습니다."
            ch.enableVibration(true)
            ch.vibrationPattern = VIB2
            ch.setBypassDnd(true)
            ch.setSound(null, null)
            m.createNotificationChannel(ch)
        }

        if (m.getNotificationChannel(CH_STATUS) == null) {
            val ch = NotificationChannel(
                CH_STATUS, "시간외 근무 중", NotificationManager.IMPORTANCE_LOW
            )
            ch.description = "근무 중인 동안 누적 시간과 다음 확인 시각을 조용히 보여 줍니다."
            ch.setSound(null, null)
            m.createNotificationChannel(ch)
        }
    }

    private fun openApp(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            ctx, 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun action(ctx: Context, what: String, rc: Int): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java).setAction(what)
        return PendingIntent.getBroadcast(
            ctx, rc, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** 저녁에 한 번: 오늘 시간외 해요? */
    fun showAsk(ctx: Context, p: Prefs) {
        ensureChannels(ctx)
        val first = Scheduler.todayAt(p.firstHour, p.firstMinute)
        val t = Totals.of(ctx, p)
        val n = NotificationCompat.Builder(ctx, CH_ASK)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("오늘 시간외 근무 해요?")
            .setContentText("[예]를 누르면 ${Scheduler.fmt(first)}부터 진동으로 알려 드려요.")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "[예]를 누르면 ${Scheduler.fmt(first)}부터 " +
                        "${p.intervalMin}분마다 진동으로 알려 드려요.\n" +
                        "이번 달 누적 ${WorkLog.text(t.month)} / ${WorkLog.text(t.cap)}" +
                        " (남은 ${WorkLog.text(t.left)})"
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(openApp(ctx))
            .addAction(0, "예", action(ctx, ActionReceiver.A_YES, 201))
            .addAction(0, "아니오", action(ctx, ActionReceiver.A_NO, 202))
            .build()
        nm(ctx).notify(ID_ASK, n)
        vibrate(ctx, VIB1)
    }

    /**
     * 확인 누르라고 진동으로 알리기.
     * stage 1 = 첫 알림, stage 2 = 마지막 알림(그 뒤로는 퇴근으로 본다).
     */
    fun showNag(ctx: Context, p: Prefs, stage: Int) {
        ensureChannels(ctx)
        val next = Scheduler.nextCheckAfter(p, System.currentTimeMillis())
        val tail = if (next > 0) "다음 확인은 ${Scheduler.fmt(next)}" else "오늘 마지막 확인이에요"
        val last = stage >= Scheduler.MAX_NAG

        val body = if (last) {
            "업무 시스템에서 확인을 누른 뒤 아래 [확인했어요]를 눌러 주세요.\n" +
                "${p.snoozeMin}분 안에 반응이 없으면 퇴근한 것으로 보고 오늘을 종료해요.\n$tail"
        } else {
            "업무 시스템에서 확인을 누른 뒤 아래 [확인했어요]를 눌러 주세요.\n" +
                "안 누르면 ${p.snoozeMin}분 뒤에 한 번 더 알려 드려요.\n$tail"
        }

        val n = NotificationCompat.Builder(ctx, CH_ALARM)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(
                if (last) "아직 확인을 안 눌렀어요 (마지막 알림)" else "지금 시간외 확인 누르세요"
            )
            .setContentText(if (last) "${p.snoozeMin}분 뒤엔 퇴근으로 보고 종료해요 · $tail" else tail)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVibrate(if (last) VIB2 else VIB1)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(openApp(ctx))
            .addAction(0, "확인했어요", action(ctx, ActionReceiver.A_DONE, 203))
            .addAction(0, "30분 미루기", action(ctx, ActionReceiver.A_SNOOZE, 206))
            .addAction(0, "오늘 종료", action(ctx, ActionReceiver.A_FINISH, 204))
            .build()

        nm(ctx).notify(ID_NAG, n)
        vibrate(ctx, if (last) VIB2 else VIB1)
    }

    /** 근무 중임과 누적 시간을 조용히 보여 주는 상주 알림 */
    fun showStatus(ctx: Context, p: Prefs) {
        ensureChannels(ctx)
        if (!p.isActive()) {
            nm(ctx).cancel(ID_STATUS)
            return
        }
        val t = Totals.of(ctx, p)
        val next = Scheduler.nextCheckAfter(p, System.currentTimeMillis())
        val line = if (next > 0) {
            "다음 확인 ${Scheduler.fmt(next)} · ${Scheduler.fmt(p.activeUntil)} 자동 종료"
        } else {
            "오늘 확인은 끝났어요 · ${Scheduler.fmt(p.activeUntil)} 자동 종료"
        }
        val kind = if (p.activeHoliday) "휴일 근무" else "평일 시간외"

        val n = NotificationCompat.Builder(ctx, CH_STATUS)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("시간외 근무 중 · 오늘 ${WorkLog.text(t.today)}")
            .setContentText(line)
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "$line\n" +
                        "$kind · ${Scheduler.fmt(p.dayStart)}부터\n" +
                        "이번 달 ${WorkLog.text(t.month)} / ${WorkLog.text(t.cap)}" +
                        " (남은 ${WorkLog.text(t.left)})"
                )
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(openApp(ctx))
            .addAction(0, "확인했어요", action(ctx, ActionReceiver.A_DONE, 207))
            .addAction(0, "30분 미루기", action(ctx, ActionReceiver.A_SNOOZE, 208))
            .addAction(0, "오늘 종료", action(ctx, ActionReceiver.A_FINISH, 205))
            .build()
        nm(ctx).notify(ID_STATUS, n)
    }

    /** 하루를 마쳤을 때 결과 요약 */
    fun showDone(ctx: Context, p: Prefs, reason: Scheduler.Reason, earned: Int) {
        ensureChannels(ctx)
        val t = Totals.of(ctx, p)
        val title = when (reason) {
            Scheduler.Reason.AWAY -> "퇴근한 것 같아 종료했어요"
            Scheduler.Reason.AUTO -> "자동 종료했어요"
            Scheduler.Reason.MANUAL -> "오늘 시간외 종료"
        }
        val warn = when {
            t.full -> "\n⚠ 이번 달 한도 ${WorkLog.text(t.cap)}를 채웠어요."
            t.nearlyFull -> "\n⚠ 한도까지 ${WorkLog.text(t.left)} 남았어요."
            else -> ""
        }
        val b = NotificationCompat.Builder(ctx, CH_STATUS)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText("오늘 ${WorkLog.text(earned)} · 이번 달 ${WorkLog.text(t.month)}")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "오늘 인정 ${WorkLog.text(earned)}\n" +
                        "이번 주 ${WorkLog.text(t.week)}\n" +
                        "이번 달 ${WorkLog.text(t.month)} / ${WorkLog.text(t.cap)}" +
                        " (남은 ${WorkLog.text(t.left)})$warn"
                )
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))

        if (reason == Scheduler.Reason.AWAY) {
            b.addAction(0, "아니에요, 계속", action(ctx, ActionReceiver.A_RESUME, 209))
        }
        nm(ctx).notify(ID_DONE, b.build())
    }

    fun cancelAsk(ctx: Context) = nm(ctx).cancel(ID_ASK)
    fun cancelNag(ctx: Context) = nm(ctx).cancel(ID_NAG)
    fun cancelDone(ctx: Context) = nm(ctx).cancel(ID_DONE)

    fun cancelAll(ctx: Context) {
        val m = nm(ctx)
        m.cancel(ID_ASK)
        m.cancel(ID_NAG)
        m.cancel(ID_STATUS)
    }

    fun vibrate(ctx: Context, pattern: LongArray) {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (e: Exception) {
            // 진동을 못 쓰는 상황이면 알림만으로 충분하다
        }
    }

    fun vibrateTest(ctx: Context) = vibrate(ctx, VIB2)
}
