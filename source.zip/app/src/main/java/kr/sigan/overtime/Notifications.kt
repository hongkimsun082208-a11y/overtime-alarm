package kr.sigan.overtime

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat

/** 알림을 만들어 띄우는 곳. 소리는 쓰지 않고 진동만 쓴다. 휴일에는 띄우지 않는다. */
object Notifications {

    private const val CH_ASK = "ask_v3"
    private const val CH_ALARM = "alarm_vib_v3"
    private const val CH_STATUS = "status"

    private const val ID_ASK = 1
    private const val ID_NAG = 2
    private const val ID_STATUS = 3
    private const val ID_DONE = 4

    /** 짧게 세 번 */
    private val VIB1 = longArrayOf(0, 500, 300, 500, 300, 500)

    /** 길게 네 번 */
    private val VIB2 = longArrayOf(0, 900, 350, 900, 350, 900, 350, 900)

    private fun nm(ctx: Context) =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val m = nm(ctx)

        if (m.getNotificationChannel(CH_ASK) == null) {
            val ch = NotificationChannel(
                CH_ASK, "시간외 근무 여부 질문", NotificationManager.IMPORTANCE_HIGH
            )
            ch.description = "평일 17:50에 오늘 시간외를 하는지 물어봅니다. 진동만 울립니다."
            ch.enableVibration(true)
            ch.vibrationPattern = VIB1
            ch.setSound(null, null)
            m.createNotificationChannel(ch)
        }

        if (m.getNotificationChannel(CH_ALARM) == null) {
            val ch = NotificationChannel(
                CH_ALARM, "확인 알람 (진동)", NotificationManager.IMPORTANCE_HIGH
            )
            ch.description = "업무 시스템에서 확인 누를 시간을 진동으로 알려 줍니다."
            ch.enableVibration(true)
            ch.vibrationPattern = VIB2
            ch.setBypassDnd(true)
            ch.setSound(null, null)
            m.createNotificationChannel(ch)
        }

        if (m.getNotificationChannel(CH_STATUS) == null) {
            val ch = NotificationChannel(
                CH_STATUS, "시간외 근무 중", NotificationManager.IMPORTANCE_LOW
            )
            ch.description = "근무 중 누적 시간과 다음 확인 시각을 조용히 보여 줍니다."
            ch.setSound(null, null)
            m.createNotificationChannel(ch)
        }
    }

    private fun openApp(ctx: Context, editDay: Int = 0): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (editDay > 0) i.putExtra(MainActivity.EXTRA_EDIT_DAY, editDay)
        return PendingIntent.getActivity(
            ctx, if (editDay > 0) 1 else 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun action(ctx: Context, what: String, rc: Int): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java).setAction(what)
        return PendingIntent.getBroadcast(
            ctx, rc, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** 평일 17:50: 오늘 시간외 해요? */
    fun showAsk(ctx: Context, p: Prefs) {
        ensureChannels(ctx)
        val key = Holidays.keyToday()
        val from = Scheduler.eveningCountFrom(ctx, p, key)
        val early = WorkLog(ctx).isEarly(key)
        val first = Scheduler.todayAt(p.firstHour, p.firstMinute)
        val t = Totals.of(ctx, p)
        val why = if (early) "8시 전 출근한 날이라 ${Scheduler.fmt(from)}부터 셉니다"
        else "${Scheduler.fmt(from)}부터 셉니다"

        val n = NotificationCompat.Builder(ctx, CH_ASK)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("오늘 시간외 해요?")
            .setContentText(why)
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "$why\n" +
                        "확인 진동: ${Scheduler.fmt(first)}부터 매 ${p.intervalMin}분\n" +
                        "이번 달 ${WorkLog.text(t.month)} / ${WorkLog.text(t.cap)}"
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(openApp(ctx))
            .addAction(0, "예", action(ctx, ActionReceiver.A_YES, 201))
            .addAction(0, "아니오", action(ctx, ActionReceiver.A_NO, 202))
            .build()
        nm(ctx).notify(ID_ASK, n)
        vibrate(ctx, VIB1)
    }

    /** 매시 30분: 업무 시스템에서 확인 누를 시간 */
    fun showNag(ctx: Context, p: Prefs, stage: Int) {
        ensureChannels(ctx)
        val t = Totals.of(ctx, p)
        val next = Scheduler.nextCheckAfter(p, System.currentTimeMillis())
        val tail = if (next > 0) "다음은 ${Scheduler.fmt(next)}" else "오늘 마지막 확인"
        val again = stage >= Scheduler.MAX_NAG

        val n = NotificationCompat.Builder(ctx, CH_ALARM)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(if (again) "아직 확인 안 눌렀어요" else "업무 시스템에서 확인 누를 시간")
            .setContentText("지금까지 ${WorkLog.text(t.today)} · $tail")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "지금까지 ${WorkLog.text(t.today)} · $tail\n" +
                        "업무 시스템에서 누른 뒤 [눌렀어요], 퇴근하면 [퇴근]"
                )
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVibrate(if (again) VIB2 else VIB1)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(openApp(ctx))
            .addAction(0, "눌렀어요", action(ctx, ActionReceiver.A_DONE, 203))
            .addAction(0, "퇴근", action(ctx, ActionReceiver.A_LEAVE, 204))
            .build()

        nm(ctx).notify(ID_NAG, n)
        vibrate(ctx, if (again) VIB2 else VIB1)
    }

    /** 평일 시간외 중 조용히 떠 있는 알림. 휴일에는 띄우지 않는다. */
    fun showStatus(ctx: Context, p: Prefs) {
        ensureChannels(ctx)
        if (!p.isActive() || p.activeHoliday) {
            nm(ctx).cancel(ID_STATUS)
            return
        }
        val t = Totals.of(ctx, p)
        val next = Scheduler.nextCheckAfter(p, System.currentTimeMillis())
        val from = Scheduler.eveningCountFrom(ctx, p, p.activeDateKey)
        val line = if (next > 0) "다음 확인 ${Scheduler.fmt(next)} · 이번 달 ${WorkLog.text(t.month)}"
        else "오늘 확인 끝 · 이번 달 ${WorkLog.text(t.month)}"

        val n = NotificationCompat.Builder(ctx, CH_STATUS)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("시간외 중 · ${WorkLog.text(t.today)}")
            .setContentText(line)
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "$line\n${Scheduler.fmt(from)}부터 누적 · 퇴근 안 누르면 00시에 자동 종료"
                )
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(openApp(ctx))
            .addAction(0, "눌렀어요", action(ctx, ActionReceiver.A_DONE, 207))
            .addAction(0, "퇴근", action(ctx, ActionReceiver.A_LEAVE, 205))
            .build()
        nm(ctx).notify(ID_STATUS, n)
    }

    /** 퇴근 결과. 00시 자동 종료면 고치라고 알린다. */
    fun showDone(ctx: Context, p: Prefs, reason: Scheduler.Reason, total: Int) {
        ensureChannels(ctx)
        val t = Totals.of(ctx, p)
        val key = p.activeDateKey
        val auto = reason == Scheduler.Reason.AUTO
        val title = if (auto) "퇴근을 안 눌러 00시까지 기록했어요"
        else "오늘 ${WorkLog.text(total)} 기록했어요"
        val warn = when {
            t.full -> "\n⚠ 이번 달 한도 ${WorkLog.text(t.cap)}를 채웠어요"
            t.nearlyFull -> "\n⚠ 한도까지 ${WorkLog.text(t.left)} 남았어요"
            else -> ""
        }
        val body = (if (auto) "실제 퇴근 시각으로 고쳐 주세요\n" else "") +
            "${WorkLog.dayText(key)} 합계 ${WorkLog.text(total)}\n" +
            "이번 달 ${WorkLog.text(t.month)} / ${WorkLog.text(t.cap)}$warn"

        // 00시에 진동으로 깨우지 않게 조용한 채널로
        val b = NotificationCompat.Builder(ctx, CH_STATUS)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(if (auto) "실제 퇴근 시각으로 고쳐 주세요" else "이번 달 ${WorkLog.text(t.month)}")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(if (auto) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, if (auto) key else 0))
        if (auto) b.addAction(0, "퇴근 시각 고치기", openApp(ctx, key))
        nm(ctx).notify(ID_DONE, b.build())
    }

    fun cancelAsk(ctx: Context) = nm(ctx).cancel(ID_ASK)
    fun cancelNag(ctx: Context) = nm(ctx).cancel(ID_NAG)
    fun cancelDone(ctx: Context) = nm(ctx).cancel(ID_DONE)

    fun cancelAll(ctx: Context) {
        val m = nm(ctx)
        m.cancel(ID_ASK)
        m.cancel(ID_NAG)
        m.cancel(ID_STATUS)
    }

    fun vibrate(ctx: Context, pattern: LongArray) {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (e: Exception) {
            // 진동을 못 쓰는 상황이면 알림만으로 충분하다
        }
    }

    /** 진동 테스트용 */
    fun showTest(ctx: Context) {
        ensureChannels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_ALARM)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("진동 테스트")
            .setContentText("이렇게 매시 30분에 알려 드려요")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .build()
        nm(ctx).notify(ID_NAG, n)
        vibrate(ctx, VIB2)
    }
}
