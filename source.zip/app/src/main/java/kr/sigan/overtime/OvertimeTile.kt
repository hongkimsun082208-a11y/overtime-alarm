package kr.sigan.overtime

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/**
 * 상단바 타일. 근무 중이면 누르면 퇴근,
 * 아니면 휴일·8시 전에는 출근, 그 밖의 평일에는 시간외 시작.
 */
class OvertimeTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        update()
    }

    override fun onClick() {
        super.onClick()
        val p = Prefs(this)
        Notifications.ensureChannels(this)
        Scheduler.catchUp(this, p)
        val msg = when {
            p.isActive() -> {
                val total = Scheduler.leave(this, p, Scheduler.Reason.MANUAL)
                "퇴근 · 오늘 ${WorkLog.text(total)}"
            }
            Scheduler.holidayToday(p) || Scheduler.beforeEarly(p) -> Scheduler.arrive(this, p)
            else -> Scheduler.startEvening(this, p)
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        update()
    }

    private fun update() {
        val t = qsTile ?: return
        val p = Prefs(this)
        when {
            p.isActive() -> {
                t.state = Tile.STATE_ACTIVE
                t.label = "퇴근"
                t.contentDescription = "근무 중 — 누르면 퇴근"
            }
            Scheduler.holidayToday(p) || Scheduler.beforeEarly(p) -> {
                t.state = Tile.STATE_INACTIVE
                t.label = "출근"
                t.contentDescription = "누르면 출근 기록"
            }
            else -> {
                t.state = Tile.STATE_INACTIVE
                t.label = "시간외 시작"
                t.contentDescription = "누르면 저녁 시간외 시작"
            }
        }
        t.updateTile()
    }
}
