package kr.sigan.overtime

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * 상단바를 내려서 한 번 눌러 시간외를 켜고 끄는 타일.
 * 주말·공휴일처럼 물어보지 않는 날에 쓰면 편하다.
 */
class OvertimeTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        update()
    }

    override fun onClick() {
        super.onClick()
        val p = Prefs(this)
        Notifications.ensureChannels(this)
        if (p.isActive()) {
            Scheduler.finishDay(this, p, Scheduler.Reason.MANUAL)
        } else {
            Scheduler.startDay(this, p)
        }
        update()
    }

    private fun update() {
        val t = qsTile ?: return
        val p = Prefs(this)
        if (p.isActive()) {
            t.state = Tile.STATE_ACTIVE
            t.label = "시간외 중"
            t.contentDescription = "시간외 근무 중 — 누르면 종료"
        } else {
            t.state = Tile.STATE_INACTIVE
            t.label = "시간외 시작"
            t.contentDescription = "누르면 오늘 시간외를 시작"
        }
        t.updateTile()
    }
}
