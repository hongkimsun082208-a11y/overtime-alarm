package kr.sigan.overtime

import android.content.Context

/** 설정값과 "오늘 시간외 근무 중" 상태를 담아 두는 곳. */
class Prefs(context: Context) {

    private val sp = context.getSharedPreferences("overtime", Context.MODE_PRIVATE)

    private fun int(key: String, def: Int) = sp.getInt(key, def)
    private fun putInt(key: String, v: Int) = sp.edit().putInt(key, v).apply()
    private fun bool(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun putBool(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()
    private fun long(key: String, def: Long) = sp.getLong(key, def)
    private fun putLong(key: String, v: Long) = sp.edit().putLong(key, v).apply()

    // ---------- 켜고 끄기 ----------

    /** 앱 전체 사용 여부 */
    var enabled: Boolean
        get() = bool("enabled", true)
        set(v) = putBool("enabled", v)

    /** 주말·공휴일에도 저녁 질문을 받을지. 기본은 받지 않고 직접 시작한다. */
    var askOnHolidays: Boolean
        get() = bool("askOnHolidays", false)
        set(v) = putBool("askOnHolidays", v)

    // ---------- 시각 설정 ----------

    /** "오늘 시간외 해요?" 를 물어보는 시각 */
    var askHour: Int
        get() = int("askHour", 17)
        set(v) = putInt("askHour", v)
    var askMinute: Int
        get() = int("askMinute", 50)
        set(v) = putInt("askMinute", v)

    /** 첫 확인 시각 */
    var firstHour: Int
        get() = int("firstHour", 19)
        set(v) = putInt("firstHour", v)
    var firstMinute: Int
        get() = int("firstMinute", 30)
        set(v) = putInt("firstMinute", v)

    /** 확인 간격(분) */
    var intervalMin: Int
        get() = int("intervalMin", 60)
        set(v) = putInt("intervalMin", v)

    /** 자동 종료 시각 */
    var endHour: Int
        get() = int("endHour", 22)
        set(v) = putInt("endHour", v)
    var endMinute: Int
        get() = int("endMinute", 0)
        set(v) = putInt("endMinute", v)

    /** 확인을 안 눌렀을 때 한 번 더 알리기까지의 간격(분) */
    var snoozeMin: Int
        get() = int("snoozeMin", 3)
        set(v) = putInt("snoozeMin", v)

    // ---------- 시간 계산 규칙 ----------

    /** 평일 시간외를 세기 시작하는 시각(정규 근무 종료 시각) */
    var startHour: Int
        get() = int("startHour", 18)
        set(v) = putInt("startHour", v)
    var startMinute: Int
        get() = int("startMinute", 0)
        set(v) = putInt("startMinute", v)

    /** 석식 공제(분) */
    var dinnerMin: Int
        get() = int("dinnerMin", 60)
        set(v) = putInt("dinnerMin", v)

    /** 휴일 근무에도 석식을 공제할지 */
    var dinnerOnHoliday: Boolean
        get() = bool("dinnerOnHoliday", false)
        set(v) = putBool("dinnerOnHoliday", v)

    /** 평일 하루 인정 한도(분) */
    var weekdayCapMin: Int
        get() = int("weekdayCapMin", 240)
        set(v) = putInt("weekdayCapMin", v)

    /** 휴일 하루 인정 한도(분) */
    var holidayCapMin: Int
        get() = int("holidayCapMin", 480)
        set(v) = putInt("holidayCapMin", v)

    /** 한 달 인정 한도(분) */
    var monthlyCapMin: Int
        get() = int("monthlyCapMin", 35 * 60)
        set(v) = putInt("monthlyCapMin", v)

    // ---------- 오늘의 상태 ----------

    /** 이 시각까지 "시간외 근무 중". 0이면 근무 중 아님. */
    var activeUntil: Long
        get() = long("activeUntil", 0L)
        set(v) = putLong("activeUntil", v)

    /** 확인 시각 계산의 기준점 */
    var anchor: Long
        get() = long("anchor", 0L)
        set(v) = putLong("anchor", v)

    /** 오늘 시간외를 세기 시작한 시각 */
    var dayStart: Long
        get() = long("dayStart", 0L)
        set(v) = putLong("dayStart", v)

    /** 마지막으로 [확인했어요] 를 누른 시각 */
    var lastDone: Long
        get() = long("lastDone", 0L)
        set(v) = putLong("lastDone", v)

    /** 지금 확인 버튼을 기다리는 중인지 */
    var pendingCheck: Boolean
        get() = bool("pendingCheck", false)
        set(v) = putBool("pendingCheck", v)

    /** 이번 확인을 몇 번째로 알렸는지 (1차, 2차) */
    var nagCount: Int
        get() = int("nagCount", 0)
        set(v) = putInt("nagCount", v)

    /** 지금 돌고 있는 하루가 휴일 근무인지 */
    var activeHoliday: Boolean
        get() = bool("activeHoliday", false)
        set(v) = putBool("activeHoliday", v)

    /** 지금 돌고 있는 하루의 날짜 (20261103) */
    var activeDateKey: Int
        get() = int("activeDateKey", 0)
        set(v) = putInt("activeDateKey", v)

    fun isActive(): Boolean = activeUntil > System.currentTimeMillis()

    // ---------- 하루 성격 직접 지정 ----------

    /** null = 자동 판정, true = 휴일로 계산, false = 평일로 계산 */
    fun dayTypeOverride(dateKey: Int): Boolean? {
        val v = int("ovr_$dateKey", -1)
        return if (v < 0) null else v == 1
    }

    fun setDayTypeOverride(dateKey: Int, holiday: Boolean?) {
        if (holiday == null) sp.edit().remove("ovr_$dateKey").apply()
        else putInt("ovr_$dateKey", if (holiday) 1 else 0)
    }
}
