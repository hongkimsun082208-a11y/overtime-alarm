package kr.sigan.overtime

import android.content.Context

/** 설정값과 "지금 근무 중" 상태를 담아 두는 곳. */
class Prefs(context: Context) {

    private val sp = context.getSharedPreferences("overtime", Context.MODE_PRIVATE)

    private fun int(key: String, def: Int) = sp.getInt(key, def)
    private fun putInt(key: String, v: Int) = sp.edit().putInt(key, v).apply()
    private fun bool(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun putBool(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()
    private fun long(key: String, def: Long) = sp.getLong(key, def)
    private fun putLong(key: String, v: Long) = sp.edit().putLong(key, v).apply()

    // ---------- 알림 ----------

    /** 평일 알림 사용 여부 (주말·공휴일은 원래 알림이 없다) */
    var enabled: Boolean
        get() = bool("enabled", true)
        set(v) = putBool("enabled", v)

    /** "오늘 시간외 해요?" 를 물어보는 시각 */
    var askHour: Int
        get() = int("askHour", 17)
        set(v) = putInt("askHour", v)
    var askMinute: Int
        get() = int("askMinute", 50)
        set(v) = putInt("askMinute", v)

    /** 첫 확인 시각. 이 시각부터 간격마다 고정으로 울린다(19:30, 20:30 …). */
    var firstHour: Int
        get() = int("firstHour", 19)
        set(v) = putInt("firstHour", v)
    var firstMinute: Int
        get() = int("firstMinute", 30)
        set(v) = putInt("firstMinute", v)

    /** 확인 간격(분) */
    var intervalMin: Int
        get() = int("intervalMin", 60)
        set(v) = putInt("intervalMin", v)

    /** 확인을 안 눌렀을 때 한 번 더 진동하기까지(분) */
    var snoozeMin: Int
        get() = int("snoozeMin", 3)
        set(v) = putInt("snoozeMin", v)

    // ---------- 시간 계산 규칙 ----------

    /** 평일 시간외 기산 시각(정규 퇴근) */
    var startHour: Int
        get() = int("startHour", 18)
        set(v) = putInt("startHour", v)
    var startMinute: Int
        get() = int("startMinute", 0)
        set(v) = putInt("startMinute", v)

    /** 공제(분). 8시 전에 출근한 날은 빼지 않는다. */
    var dinnerMin: Int
        get() = int("dinnerMin", 60)
        set(v) = putInt("dinnerMin", v)

    /** 조기 출근 기준 시각. 이 전에 출근하면 출근~이 시각이 시간외, 저녁 공제 없음. */
    var earlyHour: Int
        get() = int("earlyHour", 8)
        set(v) = putInt("earlyHour", v)
    var earlyMinute: Int
        get() = int("earlyMinute", 0)
        set(v) = putInt("earlyMinute", v)

    /** 한 달 인정 한도(분) */
    var monthlyCapMin: Int
        get() = int("monthlyCapMin", 35 * 60)
        set(v) = putInt("monthlyCapMin", v)

    // ---------- 지금 상태 ----------

    /** 이 시각까지 근무 중(자정 자동 종료 시각). 0이면 근무 중 아님. */
    var activeUntil: Long
        get() = long("activeUntil", 0L)
        set(v) = putLong("activeUntil", v)

    /** 지금 구간을 세기 시작한 시각 (평일 저녁은 18:00, 휴일은 출근 시각) */
    var dayStart: Long
        get() = long("dayStart", 0L)
        set(v) = putLong("dayStart", v)

    /** 확인 진동을 기다리는 중인지 */
    var pendingCheck: Boolean
        get() = bool("pendingCheck", false)
        set(v) = putBool("pendingCheck", v)

    /** 이번 확인을 몇 번째로 알렸는지 */
    var nagCount: Int
        get() = int("nagCount", 0)
        set(v) = putInt("nagCount", v)

    /** 지금 구간이 휴일 근무인지 */
    var activeHoliday: Boolean
        get() = bool("activeHoliday", false)
        set(v) = putBool("activeHoliday", v)

    /** 지금 구간의 날짜 (20261103) */
    var activeDateKey: Int
        get() = int("activeDateKey", 0)
        set(v) = putInt("activeDateKey", v)

    fun isActive(): Boolean = activeUntil > System.currentTimeMillis()

    /** 지금 구간의 종류: E=평일 저녁, H=휴일 */
    fun activeKind(): Char = if (activeHoliday) 'H' else 'E'

    // ---------- 하루 성격 직접 지정 ----------

    /** null = 자동 판정, true = 휴일로 계산, false = 평일로 계산 */
    fun dayTypeOverride(dateKey: Int): Boolean? {
        val v = int("ovr_$dateKey", -1)
        return if (v < 0) null else v == 1
    }

    fun setDayTypeOverride(dateKey: Int, holiday: Boolean?) {
        if (holiday == null) sp.edit().remove("ovr_$dateKey").apply()
        else putInt("ovr_$dateKey", if (holiday) 1 else 0)
    }
}
