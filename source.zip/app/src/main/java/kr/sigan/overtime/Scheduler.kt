package kr.sigan.overtime

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 알람 예약과 출근·시간외 시작·퇴근을 모아 둔 곳.
 *
 * 평일: 17:50 질문 → [예] → 19:30, 20:30 … 매시 30분 고정으로 확인 진동 → [퇴근]
 * 휴일: [출근] → [퇴근]. 알림 없이 누적만.
 * 퇴근을 안 누르면 00시에 자동으로 끝낸다.
 */
object Scheduler {

    const val ACTION_ASK = "kr.sigan.overtime.ASK"
    const val ACTION_CHECK = "kr.sigan.overtime.CHECK"
    const val ACTION_NAG = "kr.sigan.overtime.NAG"
    const val ACTION_END = "kr.sigan.overtime.END"

    private const val RC_ASK = 101
    private const val RC_CHECK = 102
    private const val RC_NAG = 103
    private const val RC_END = 104

    /** 확인 진동 횟수(처음 + 한 번 더) */
    const val MAX_NAG = 2

    /** 퇴근 이유 */
    enum class Reason { MANUAL, AUTO }

    private const val MINUTE = 60_000L
    private const val HOUR = 60 * MINUTE
    private const val DAY = 24 * HOUR

    private fun am(ctx: Context) =
        ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pi(ctx: Context, action: String, rc: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            ctx, rc, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** asAlarmClock 이면 시계 알람과 같은 등급으로 걸어서 절전 모드에서도 정확히 울린다. */
    private fun setExact(ctx: Context, at: Long, action: String, rc: Int, asAlarmClock: Boolean) {
        val a = am(ctx)
        val p = pi(ctx, action, rc)
        val canExact =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) a.canScheduleExactAlarms() else true
        try {
            when {
                canExact && asAlarmClock ->
                    a.setAlarmClock(AlarmManager.AlarmClockInfo(at, p), p)
                canExact ->
                    a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                else ->
                    a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            }
        } catch (e: SecurityException) {
            a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    private fun cancel(ctx: Context, action: String, rc: Int) {
        am(ctx).cancel(pi(ctx, action, rc))
    }

    // ----- 예약 -----

    /** 다음 평일 17:50 질문 예약 */
    fun scheduleAsk(ctx: Context, p: Prefs) {
        cancel(ctx, ACTION_ASK, RC_ASK)
        if (!p.enabled) return
        setExact(ctx, nextAskTime(p), ACTION_ASK, RC_ASK, false)
    }

    /** 근무 중일 때 다음 확인(평일만)과 00시 자동 종료를 예약 */
    fun scheduleNextCheck(ctx: Context, p: Prefs) {
        cancel(ctx, ACTION_CHECK, RC_CHECK)
        cancel(ctx, ACTION_END, RC_END)
        if (p.activeUntil <= 0L) return
        if (!p.activeHoliday && p.enabled) {
            val t = nextCheckAfter(p, System.currentTimeMillis())
            if (t > 0) setExact(ctx, t, ACTION_CHECK, RC_CHECK, true)
        }
        setExact(ctx, p.activeUntil, ACTION_END, RC_END, false)
    }

    /** 확인을 안 눌렀을 때 한 번 더 진동 */
    fun scheduleNag(ctx: Context, p: Prefs) {
        cancelNag(ctx)
        val at = System.currentTimeMillis() + p.snoozeMin.coerceAtLeast(1) * MINUTE
        setExact(ctx, at, ACTION_NAG, RC_NAG, true)
    }

    fun cancelNag(ctx: Context) = cancel(ctx, ACTION_NAG, RC_NAG)

    // ----- 출근 / 시간외 시작 / 퇴근 -----

    /** 오늘이 휴일(주말·공휴일·직접 지정)인지 */
    fun holidayToday(p: Prefs): Boolean = Holidays.isHolidayFor(p, Calendar.getInstance())

    /** 지금이 조기 출근 기준(08:00) 전인지 */
    fun beforeEarly(p: Prefs): Boolean =
        System.currentTimeMillis() < todayAt(p.earlyHour, p.earlyMinute)

    /**
     * [출근] — 평일 8시 전이면 출근~08:00 을 기록(그날 저녁 공제 없음),
     * 휴일이면 휴일 근무를 시작한다. 결과를 사람이 읽을 문장으로 돌려준다.
     */
    fun arrive(ctx: Context, p: Prefs): String {
        val now = floorMinute(System.currentTimeMillis())
        val key = Holidays.keyToday()
        val log = WorkLog(ctx)

        if (holidayToday(p)) {
            if (p.isActive()) return "이미 근무 중이에요"
            p.activeDateKey = key
            p.activeHoliday = true
            p.dayStart = now
            p.activeUntil = nextMidnight()
            p.pendingCheck = false
            p.nagCount = 0
            Notifications.cancelDone(ctx)
            scheduleNextCheck(ctx, p)
            return "휴일 출근 ${fmt(now)} — 퇴근 누를 때까지 셉니다"
        }

        val early = todayAt(p.earlyHour, p.earlyMinute)
        if (now >= early) {
            return "${fmt(early)} 이후 출근은 따로 기록하지 않아요 (저녁은 19시부터 셉니다)"
        }
        // 이미 눌렀으면 덮어쓰지 않는다(고치는 건 기록 화면에서)
        val already = log.arrival(key)
        if (already > 0L) return "이미 ${fmt(already)} 출근으로 기록돼 있어요"
        log.addSegment(p, key, WorkLog.Seg('M', now, early))
        if (p.isActive()) Notifications.showStatus(ctx, p)
        return "출근 ${fmt(now)} — ${fmt(early)}까지 시간외, 오늘 저녁은 18시부터 셉니다"
    }

    /** 평일 저녁 시간외 시작 ([예], [시간외 시작]). 휴일이면 출근으로 처리한다. */
    fun startEvening(ctx: Context, p: Prefs): String {
        if (p.isActive()) return "이미 근무 중이에요"
        if (holidayToday(p)) return arrive(ctx, p)

        val key = Holidays.keyToday()
        p.activeDateKey = key
        p.activeHoliday = false
        p.dayStart = todayAt(p.startHour, p.startMinute)
        p.activeUntil = nextMidnight()
        p.pendingCheck = false
        p.nagCount = 0

        Notifications.cancelAsk(ctx)
        Notifications.cancelDone(ctx)
        scheduleNextCheck(ctx, p)
        Notifications.showStatus(ctx, p)
        return "시간외 시작 — ${fmt(eveningCountFrom(ctx, p, key))}부터 누적"
    }

    /** 그날 저녁 시간외가 실제로 쌓이기 시작하는 시각 (8시 전 출근이면 18:00, 아니면 19:00) */
    fun eveningCountFrom(ctx: Context, p: Prefs, key: Int): Long {
        val s = WorkLog.at(key, p.startHour, p.startMinute)
        return if (WorkLog(ctx).isEarly(key)) s else s + p.dinnerMin * MINUTE
    }

    /** [퇴근] — 구간을 마치고 기록한다. 그날 인정 합계를 돌려준다. */
    fun leave(ctx: Context, p: Prefs, reason: Reason): Int {
        val wasActive = p.activeUntil > 0L
        var total = 0
        val holiday = p.activeHoliday

        if (wasActive) {
            var end = when (reason) {
                Reason.AUTO -> p.activeUntil
                Reason.MANUAL -> floorMinute(System.currentTimeMillis())
            }
            if (end > p.activeUntil) end = p.activeUntil
            total = WorkLog(ctx).addSegment(
                p, p.activeDateKey, WorkLog.Seg(p.activeKind(), p.dayStart, end)
            )
        }

        p.activeUntil = 0L
        p.pendingCheck = false
        p.nagCount = 0

        cancelNag(ctx)
        cancel(ctx, ACTION_CHECK, RC_CHECK)
        cancel(ctx, ACTION_END, RC_END)
        Notifications.cancelAll(ctx)

        // 휴일에 직접 누른 퇴근은 알림 없이 끝. 자동 종료는 고치라고 꼭 알린다.
        if (wasActive && (reason == Reason.AUTO || !holiday)) {
            Notifications.showDone(ctx, p, reason, total)
        }
        scheduleAsk(ctx, p)
        return total
    }

    /** 폰이 꺼져 있는 사이 00시가 지났으면 자동 종료를 마저 처리한다 */
    fun catchUp(ctx: Context, p: Prefs) {
        if (p.activeUntil > 0L && !p.isActive()) leave(ctx, p, Reason.AUTO)
    }

    // ----- 시간 계산 -----

    fun floorMinute(t: Long): Long = t / MINUTE * MINUTE

    /** 진행 중인 구간(시작~지금). 진행 중이 아니면 null. */
    fun liveSegment(p: Prefs): WorkLog.Seg? {
        if (!p.isActive() || p.dayStart <= 0L) return null
        var end = floorMinute(System.currentTimeMillis())
        if (end > p.activeUntil) end = p.activeUntil
        return WorkLog.Seg(p.activeKind(), p.dayStart, end)
    }

    fun todayAt(h: Int, m: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** 오늘 밤 12시(내일 00:00) */
    fun nextMidnight(): Long = todayAt(0, 0) + DAY

    /** from 이후의 첫 확인 시각. 첫 확인 시각부터 간격마다 고정. 00시를 넘으면 -1. */
    fun nextCheckAfter(p: Prefs, from: Long): Long {
        if (p.activeUntil <= 0L || p.activeHoliday) return -1
        val step = p.intervalMin.coerceAtLeast(5) * MINUTE
        var t = WorkLog.at(p.activeDateKey, p.firstHour, p.firstMinute)
        var guard = 0
        while (t <= from + 1000 && guard++ < 2000) t += step
        return if (t < p.activeUntil) t else -1
    }

    /** 다음으로 물어볼 시각. 주말·공휴일은 건너뛴다. */
    fun nextAskTime(p: Prefs): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = todayAt(p.askHour, p.askMinute)
        if (c.timeInMillis <= System.currentTimeMillis() + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
        var guard = 0
        while (Holidays.isHolidayFor(p, c) && guard++ < 40) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private val hm = SimpleDateFormat("HH:mm", Locale.KOREA)
    private val mdhm = SimpleDateFormat("M월 d일 (E) HH:mm", Locale.KOREA)

    fun fmt(t: Long): String = hm.format(Date(t))
    fun fmtLong(t: Long): String = mdhm.format(Date(t))
}
