package kr.sigan.overtime

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** 알람 예약과 하루의 시작·종료를 모아 둔 곳. */
object Scheduler {

    const val ACTION_ASK = "kr.sigan.overtime.ASK"
    const val ACTION_CHECK = "kr.sigan.overtime.CHECK"
    const val ACTION_NAG = "kr.sigan.overtime.NAG"
    const val ACTION_END = "kr.sigan.overtime.END"

    private const val RC_ASK = 101
    private const val RC_CHECK = 102
    private const val RC_NAG = 103
    private const val RC_END = 104

    /** 진동으로 알리는 횟수. 이만큼 알리고도 반응이 없으면 퇴근으로 본다. */
    const val MAX_NAG = 2

    /** 하루를 마치는 이유 */
    enum class Reason { AUTO, MANUAL, AWAY }

    private const val MINUTE = 60_000L
    private const val HOUR = 60 * MINUTE
    private const val DAY = 24 * HOUR

    private fun am(ctx: Context) =
        ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pi(ctx: Context, action: String, rc: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            ctx, rc, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * 알람을 건다. asAlarmClock 이면 시계 알람과 같은 등급으로 걸어서
     * 절전 모드에서도 정확히 울린다.
     */
    private fun setExact(ctx: Context, at: Long, action: String, rc: Int, asAlarmClock: Boolean) {
        val a = am(ctx)
        val p = pi(ctx, action, rc)
        val canExact =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) a.canScheduleExactAlarms() else true
        try {
            when {
                canExact && asAlarmClock ->
                    a.setAlarmClock(AlarmManager.AlarmClockInfo(at, p), p)
                canExact ->
                    a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                else ->
                    a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            }
        } catch (e: SecurityException) {
            a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    private fun cancel(ctx: Context, action: String, rc: Int) {
        am(ctx).cancel(pi(ctx, action, rc))
    }

    // ----- 예약 -----

    /** 다음 "오늘 시간외 해요?" 질문 예약 */
    fun scheduleAsk(ctx: Context, p: Prefs) {
        cancel(ctx, ACTION_ASK, RC_ASK)
        if (!p.enabled) return
        setExact(ctx, nextAskTime(p), ACTION_ASK, RC_ASK, false)
    }

    /** 다음 확인 시각 예약. 더 남지 않았으면 종료 알람을 건다. */
    fun scheduleNextCheck(ctx: Context, p: Prefs) {
        cancel(ctx, ACTION_CHECK, RC_CHECK)
        cancel(ctx, ACTION_END, RC_END)
        val t = nextCheckAfter(p, System.currentTimeMillis())
        if (t > 0) {
            setExact(ctx, t, ACTION_CHECK, RC_CHECK, true)
        } else {
            setExact(ctx, p.activeUntil, ACTION_END, RC_END, false)
        }
    }

    /** 확인을 안 눌렀을 때 한 번 더 알릴 알람 */
    fun scheduleNag(ctx: Context, p: Prefs) {
        cancelNag(ctx)
        val at = System.currentTimeMillis() + p.snoozeMin.coerceAtLeast(1) * MINUTE
        setExact(ctx, at, ACTION_NAG, RC_NAG, true)
    }

    fun cancelNag(ctx: Context) = cancel(ctx, ACTION_NAG, RC_NAG)

    // ----- 하루 시작 / 종료 -----

    fun startDay(ctx: Context, p: Prefs) {
        val now = System.currentTimeMillis()
        val c = Calendar.getInstance()
        val holiday = Holidays.isHolidayFor(p, c)

        p.activeDateKey = Holidays.key(c)
        p.activeHoliday = holiday

        // 평일은 정규 퇴근 시각부터, 휴일은 시작한 지금부터 센다
        p.dayStart = if (holiday) floorMinute(now) else todayAt(p.startHour, p.startMinute)

        // 휴일은 시작 시각 기준으로 간격을 세고, 평일은 첫 확인 시각 그리드를 따른다
        p.anchor = if (holiday) floorMinute(now) else todayAt(p.firstHour, p.firstMinute)

        var end = endTimeToday(p)
        if (end <= now) end = now + 2 * HOUR
        p.activeUntil = end

        p.pendingCheck = false
        p.nagCount = 0
        p.lastDone = 0L

        Notifications.cancelAsk(ctx)
        Notifications.cancelDone(ctx)
        scheduleNextCheck(ctx, p)
        Notifications.showStatus(ctx, p)
    }

    /** 퇴근으로 보고 끝낸 하루를 다시 이어서 돌린다. */
    fun resumeDay(ctx: Context, p: Prefs) {
        val now = System.currentTimeMillis()
        if (p.dayStart <= 0L) {
            startDay(ctx, p)
            return
        }
        var end = endTimeToday(p)
        if (end <= now) end = now + 2 * HOUR
        p.activeUntil = end
        p.anchor = floorMinute(now) + p.intervalMin.coerceAtLeast(5) * MINUTE
        p.pendingCheck = false
        p.nagCount = 0

        Notifications.cancelDone(ctx)
        scheduleNextCheck(ctx, p)
        Notifications.showStatus(ctx, p)
    }

    /** 하루를 마치고 인정 시간을 기록한다. 기록한 분을 돌려준다. */
    fun finishDay(ctx: Context, p: Prefs, reason: Reason): Int {
        val wasActive = p.activeUntil > 0L
        var earned = 0

        if (wasActive) {
            val end = when (reason) {
                Reason.AUTO -> p.activeUntil
                Reason.MANUAL -> floorMinute(System.currentTimeMillis())
                Reason.AWAY -> if (p.lastDone > 0L) p.lastDone else p.dayStart
            }
            earned = minutesFor(p, p.dayStart, end, p.activeHoliday)
            if (p.activeDateKey > 0) WorkLog(ctx).putAtLeast(p.activeDateKey, earned)
        }

        p.activeUntil = 0L
        p.anchor = 0L
        p.pendingCheck = false
        p.nagCount = 0
        // dayStart / activeHoliday / activeDateKey 는 남겨 둔다. [계속] 로 이어서 돌릴 때 쓴다.

        cancelNag(ctx)
        cancel(ctx, ACTION_CHECK, RC_CHECK)
        cancel(ctx, ACTION_END, RC_END)
        Notifications.cancelAll(ctx)

        if (wasActive) Notifications.showDone(ctx, p, reason, earned)
        scheduleAsk(ctx, p)
        return earned
    }

    // ----- 시간 계산 -----

    /** 초를 버린다 */
    fun floorMinute(t: Long): Long = t / MINUTE * MINUTE

    /** start~end 구간에서 인정되는 분. 석식 공제와 하루 한도를 적용한다. */
    fun minutesFor(p: Prefs, start: Long, end: Long, holiday: Boolean): Int {
        if (start <= 0L || end <= start) return 0
        var m = ((end - start) / MINUTE).toInt()
        if (!holiday || p.dinnerOnHoliday) m -= p.dinnerMin
        if (m <= 0) return 0
        val cap = if (holiday) p.holidayCapMin else p.weekdayCapMin
        return if (m > cap) cap else m
    }

    /** 지금까지 쌓인 오늘의 인정 시간(진행 중일 때) */
    fun earnedSoFar(p: Prefs): Int =
        minutesFor(p, p.dayStart, floorMinute(System.currentTimeMillis()), p.activeHoliday)

    fun todayAt(h: Int, m: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** 오늘의 종료 시각. 기준점보다 이르면 다음 날로 넘긴다(자정 넘는 근무). */
    fun endTimeToday(p: Prefs): Long {
        var e = todayAt(p.endHour, p.endMinute)
        val base = if (p.anchor > 0L) p.anchor else todayAt(p.firstHour, p.firstMinute)
        if (e <= base) e += DAY
        return e
    }

    /** from 이후의 첫 확인 시각. 종료 시각을 넘으면 -1. */
    fun nextCheckAfter(p: Prefs, from: Long): Long {
        val step = p.intervalMin.coerceAtLeast(5) * MINUTE
        var t = if (p.anchor > 0L) p.anchor else todayAt(p.firstHour, p.firstMinute)
        val end = if (p.activeUntil > 0L) p.activeUntil else endTimeToday(p)
        var guard = 0
        while (t <= from + 1000 && guard++ < 2000) t += step
        return if (t <= end) t else -1
    }

    /** 다음으로 물어볼 시각. 주말·공휴일은 건너뛴다. */
    fun nextAskTime(p: Prefs): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = todayAt(p.askHour, p.askMinute)
        if (c.timeInMillis <= System.currentTimeMillis() + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
        if (!p.askOnHolidays) {
            var guard = 0
            while (Holidays.isHolidayFor(p, c) && guard++ < 40) c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }

    private val hm = SimpleDateFormat("a h:mm", Locale.KOREA)
    private val mdhm = SimpleDateFormat("M월 d일 (E) a h:mm", Locale.KOREA)

    fun fmt(t: Long): String = hm.format(Date(t))
    fun fmtLong(t: Long): String = mdhm.format(Date(t))
}
