package kr.sigan.overtime

import android.content.Context

/** 오늘·이번 주·이번 달 인정 시간을 한 번에 구한다. 진행 중인 구간도 반영한다. */
class Totals private constructor(
    val today: Int,
    val week: Int,
    val month: Int,
    val cap: Int
) {
    /** 월 한도까지 남은 분 */
    val left: Int get() = if (cap > month) cap - month else 0

    /** 월 한도를 채웠는지 */
    val full: Boolean get() = month >= cap

    /** 월 한도의 90% 를 넘겼는지 */
    val nearlyFull: Boolean get() = !full && cap > 0 && month * 10 >= cap * 9

    companion object {
        fun of(ctx: Context, p: Prefs): Totals {
            val log = WorkLog(ctx)
            val key = Holidays.keyToday()
            val recorded = log.get(key)
            val live = if (p.isActive() && p.activeDateKey == key) Scheduler.liveSegment(p) else null
            // 8시 전 출근 구간은 08:00 까지로 미리 적혀 있으니 지금 시각까지만 센다
            val today = log.totalNow(p, key, live)
            val plus = today - recorded
            return Totals(
                today,
                log.weekTotalNow() + plus,
                log.monthTotalNow() + plus,
                p.monthlyCapMin
            )
        }
    }
}
