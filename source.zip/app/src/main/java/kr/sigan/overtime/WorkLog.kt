package kr.sigan.overtime

import android.content.Context
import java.util.Calendar

/**
 * 하루치 기록을 구간으로 쌓아 두고 주·월 누적을 계산한다.
 *
 *  - s_<날짜> : 구간 목록 "M,시작,끝;E,시작,끝"
 *        M = 8시 전 출근 (출근 ~ 08:00)
 *        E = 평일 저녁 시간외 (18:00 ~ 퇴근)
 *        H = 휴일 근무 (출근 ~ 퇴근)
 *  - b_<날짜> : 손으로 고친 합계(또는 예전 버전 기록). 구간 합계에 더한다.
 *  - d_<날짜> : 그날 인정 합계. 주·월 누적은 이 값을 더한다.
 *
 * 계산 규칙
 *  - 8시 전에 출근한 날(M 구간이 있는 날): 출근~08:00 인정, 저녁은 18:00부터 공제 없이
 *  - 그 밖의 평일: 저녁 18:00부터 세고 공제 1시간 → 사실상 19:00부터
 *  - 휴일: 출근~퇴근 그대로
 *  - 하루 한도 없음
 */
class WorkLog(context: Context) {

    private val sp = context.getSharedPreferences("worklog", Context.MODE_PRIVATE)

    class Seg(val kind: Char, val start: Long, val end: Long)

    fun get(dateKey: Int): Int = sp.getInt("d_$dateKey", 0)

    /** 합계를 손으로 정한다. 그날 구간 기록은 지운다. */
    fun put(dateKey: Int, minutes: Int) {
        val e = sp.edit().remove("s_$dateKey")
        if (minutes <= 0) e.remove("d_$dateKey").remove("b_$dateKey")
        else e.putInt("d_$dateKey", minutes).putInt("b_$dateKey", minutes)
        e.apply()
    }

    /** 그날 기록을 모두 지운다 */
    fun clear(dateKey: Int) {
        sp.edit().remove("s_$dateKey").remove("b_$dateKey").remove("d_$dateKey").apply()
    }

    private fun base(dateKey: Int): Int = when {
        sp.contains("b_$dateKey") -> sp.getInt("b_$dateKey", 0)
        // 예전 버전은 하루 합계만 남겼다 → 그 값을 바탕으로 본다
        !sp.contains("s_$dateKey") -> get(dateKey)
        else -> 0
    }

    fun segments(dateKey: Int): List<Seg> {
        val raw = sp.getString("s_$dateKey", null) ?: return emptyList()
        val out = ArrayList<Seg>()
        for (part in raw.split(';')) {
            val f = part.split(',')
            if (f.size != 3 || f[0].isEmpty()) continue
            val s = f[1].toLongOrNull() ?: continue
            val e = f[2].toLongOrNull() ?: continue
            out.add(Seg(f[0][0], s, e))
        }
        return out
    }

    /** 그날 구간 목록을 통째로 바꾸고 합계를 다시 계산한다 */
    fun setSegments(p: Prefs, dateKey: Int, list: List<Seg>): Int {
        val b = base(dateKey)
        val clean = list.filter { it.end > it.start }
        val total = compute(p, b, clean, Long.MAX_VALUE)
        val e = sp.edit().putInt("b_$dateKey", b)
        if (clean.isEmpty()) e.remove("s_$dateKey")
        else e.putString("s_$dateKey", clean.joinToString(";") { "${it.kind},${it.start},${it.end}" })
        if (total > 0) e.putInt("d_$dateKey", total) else e.remove("d_$dateKey")
        e.apply()
        return total
    }

    /** 구간 하나를 더하고 그날 합계를 돌려준다 */
    fun addSegment(p: Prefs, dateKey: Int, seg: Seg): Int {
        if (seg.end <= seg.start) return get(dateKey)
        return setSegments(p, dateKey, segments(dateKey) + seg)
    }

    /** 8시 전 출근 기록이 있는 날인지 */
    fun isEarly(dateKey: Int): Boolean = segments(dateKey).any { it.kind == 'M' }

    /** 그날 출근 시각 (8시 전 출근 또는 휴일 출근). 없으면 0. */
    fun arrival(dateKey: Int): Long =
        segments(dateKey).filter { it.kind == 'M' || it.kind == 'H' }.minOfOrNull { it.start } ?: 0L

    /** 진행 중인 구간까지 포함해 지금 시각 기준 그날 합계 */
    fun totalNow(p: Prefs, dateKey: Int, live: Seg?): Int {
        val list = segments(dateKey)
        val all = if (live != null && live.end > live.start) list + live else list
        if (all.isEmpty()) return get(dateKey)
        return compute(p, base(dateKey), all, System.currentTimeMillis())
    }

    /** 기록 화면에 붙일 설명. 예) "아침 30분 · 저녁 2시간" */
    fun detail(p: Prefs, dateKey: Int): String {
        val list = segments(dateKey)
        if (list.isEmpty()) return ""
        val parts = ArrayList<String>()
        val b = base(dateKey)
        if (b > 0) parts.add("직접 ${text(b)}")
        val m = merged(list, 'M', Long.MAX_VALUE)
        if (m > 0) parts.add("아침 ${text(m)}")
        val e = evening(p, list, Long.MAX_VALUE)
        if (e > 0) parts.add("저녁 ${text(e)}")
        val h = merged(list, 'H', Long.MAX_VALUE)
        if (h > 0) parts.add("휴일 ${text(h)}")
        return parts.joinToString(" · ")
    }

    /** 그 달의 (날짜키 → 분) 목록, 날짜 순 */
    fun month(year: Int, month1: Int): List<Pair<Int, Int>> {
        val out = ArrayList<Pair<Int, Int>>()
        val base = year * 10000 + month1 * 100
        for (d in 1..31) {
            val m = get(base + d)
            if (m > 0 || sp.contains("s_${base + d}")) out.add(Pair(base + d, m))
        }
        return out
    }

    fun monthTotal(year: Int, month1: Int): Int {
        var sum = 0
        for (pair in month(year, month1)) sum += pair.second
        return sum
    }

    fun monthTotalNow(): Int {
        val c = Calendar.getInstance()
        return monthTotal(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1)
    }

    /** 이번 주(월~일) 누적 */
    fun weekTotalNow(): Int {
        val c = Calendar.getInstance()
        var shift = c.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY
        if (shift < 0) shift += 7
        c.add(Calendar.DAY_OF_YEAR, -shift)
        var sum = 0
        for (i in 0 until 7) {
            sum += get(Holidays.key(c))
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return sum
    }

    companion object {
        private const val MINUTE = 60_000L

        /** 그날 인정 합계. now 이후 부분은 세지 않는다. */
        fun compute(p: Prefs, base: Int, list: List<Seg>, now: Long): Int {
            val sum = base + merged(list, 'M', now) + evening(p, list, now) + merged(list, 'H', now)
            return if (sum < 0) 0 else sum
        }

        /** 평일 저녁 인정분. 8시 전 출근한 날은 공제 없음. */
        fun evening(p: Prefs, list: List<Seg>, now: Long): Int {
            val m = merged(list, 'E', now)
            if (m <= 0) return 0
            val early = list.any { it.kind == 'M' && it.start < now }
            val cut = if (early) 0 else p.dinnerMin
            return (m - cut).coerceAtLeast(0)
        }

        /** 같은 종류 구간을 겹치지 않게 합쳐서 분으로 */
        fun merged(list: List<Seg>, kind: Char, now: Long): Int {
            val xs = list
                .filter { it.kind == kind }
                .map { Seg(it.kind, it.start, if (it.end > now) now else it.end) }
                .filter { it.end > it.start }
                .sortedBy { it.start }
            var total = 0L
            var curS = -1L
            var curE = -1L
            for (s in xs) {
                if (curS < 0) {
                    curS = s.start; curE = s.end
                } else if (s.start <= curE) {
                    if (s.end > curE) curE = s.end
                } else {
                    total += curE - curS
                    curS = s.start; curE = s.end
                }
            }
            if (curS >= 0) total += curE - curS
            return (total / MINUTE).toInt()
        }

        /** 200 → "3시간 20분" */
        fun text(minutes: Int): String {
            if (minutes <= 0) return "0분"
            val h = minutes / 60
            val m = minutes % 60
            return when {
                h > 0 && m > 0 -> "${h}시간 ${m}분"
                h > 0 -> "${h}시간"
                else -> "${m}분"
            }
        }

        /** 20261103 → "11월 3일 (화)" */
        fun dayText(dateKey: Int): String {
            val c = calOf(dateKey)
            val names = arrayOf("일", "월", "화", "수", "목", "금", "토")
            val w = names[c.get(Calendar.DAY_OF_WEEK) - 1]
            return "${(dateKey / 100) % 100}월 ${dateKey % 100}일 ($w)"
        }

        /** 날짜키의 0시 Calendar */
        fun calOf(dateKey: Int): Calendar {
            val c = Calendar.getInstance()
            c.set(dateKey / 10000, (dateKey / 100) % 100 - 1, dateKey % 100, 0, 0, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c
        }

        /** 날짜키 그날의 h:m 시각 */
        fun at(dateKey: Int, h: Int, m: Int): Long {
            val c = calOf(dateKey)
            c.set(Calendar.HOUR_OF_DAY, h)
            c.set(Calendar.MINUTE, m)
            return c.timeInMillis
        }
    }
}
