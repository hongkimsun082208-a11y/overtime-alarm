package kr.sigan.overtime

import android.content.Context
import java.util.Calendar

/** 하루치 인정 시간을 쌓아 두고 주·월 누적을 계산한다. */
class WorkLog(context: Context) {

    private val sp = context.getSharedPreferences("worklog", Context.MODE_PRIVATE)

    fun get(dateKey: Int): Int = sp.getInt("d_$dateKey", 0)

    fun put(dateKey: Int, minutes: Int) {
        if (minutes <= 0) sp.edit().remove("d_$dateKey").apply()
        else sp.edit().putInt("d_$dateKey", minutes).apply()
    }

    /** 같은 날을 여러 번 기록해도 줄어들지는 않게 한다. */
    fun putAtLeast(dateKey: Int, minutes: Int) {
        if (minutes > get(dateKey)) put(dateKey, minutes)
    }

    /** 그 달의 (날짜키 → 분) 목록, 날짜 순 */
    fun month(year: Int, month1: Int): List<Pair<Int, Int>> {
        val out = ArrayList<Pair<Int, Int>>()
        val base = year * 10000 + month1 * 100
        for (d in 1..31) {
            val m = get(base + d)
            if (m > 0) out.add(Pair(base + d, m))
        }
        return out
    }

    fun monthTotal(year: Int, month1: Int): Int {
        var sum = 0
        for (pair in month(year, month1)) sum += pair.second
        return sum
    }

    fun monthTotalNow(): Int {
        val c = Calendar.getInstance()
        return monthTotal(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1)
    }

    /** 이번 주(월~일) 누적 */
    fun weekTotalNow(): Int {
        val c = Calendar.getInstance()
        var shift = c.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY
        if (shift < 0) shift += 7
        c.add(Calendar.DAY_OF_YEAR, -shift)
        var sum = 0
        for (i in 0 until 7) {
            sum += get(Holidays.key(c))
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return sum
    }

    companion object {
        /** 200 → "3시간 20분" */
        fun text(minutes: Int): String {
            if (minutes <= 0) return "0분"
            val h = minutes / 60
            val m = minutes % 60
            return when {
                h > 0 && m > 0 -> "${h}시간 ${m}분"
                h > 0 -> "${h}시간"
                else -> "${m}분"
            }
        }

        /** 20261103 → "11월 3일 (화)" */
        fun dayText(dateKey: Int): String {
            val y = dateKey / 10000
            val mo = (dateKey / 100) % 100
            val d = dateKey % 100
            val c = Calendar.getInstance()
            c.set(y, mo - 1, d, 0, 0, 0)
            val names = arrayOf("일", "월", "화", "수", "목", "금", "토")
            val w = names[c.get(Calendar.DAY_OF_WEEK) - 1]
            return "${mo}월 ${d}일 ($w)"
        }
    }
}
